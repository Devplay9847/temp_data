package com.BisagN.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.servlet.ServletListenerRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.session.SessionRegistry;
import org.springframework.security.core.session.SessionRegistryImpl;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.security.web.authentication.session.RegisterSessionAuthenticationStrategy;
import org.springframework.security.web.header.writers.ReferrerPolicyHeaderWriter.ReferrerPolicy;
import org.springframework.security.web.session.HttpSessionEventPublisher;

import com.BisagN.controller.redirectLogin;
import com.BisagN.service.CustomAuthenticationProvider;
import com.BisagN.service.ExtraParamSource;
import com.BisagN.service.UserDetailsServiceImpl;

@Configuration
@EnableWebSecurity
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {

	@Autowired
	UserDetailsServiceImpl userDetailsServiceImpl;

	@Autowired
	CustomAuthenticationProvider customAuthenticationProvider;

	@Autowired
	ExtraParamSource extraParamSource;

	@Bean
	public BCryptPasswordEncoder passwordEncoder() {
		BCryptPasswordEncoder bCryptPasswordEncoder = new BCryptPasswordEncoder();
		return bCryptPasswordEncoder;
	}

	@Autowired
	public void configureGlobal(AuthenticationManagerBuilder auth) throws Exception {
		auth.userDetailsService(userDetailsServiceImpl).passwordEncoder(passwordEncoder());
		auth.authenticationProvider(customAuthenticationProvider);

	}

//	@Autowired
//	public CustomAuthenticationProvider authProvider() {
//        CustomAuthenticationProvider authenticationProvider = new CustomAuthenticationProvider();
//        return authenticationProvider;
//    }

	@Override
	protected void configure(HttpSecurity http) throws Exception {

		http.headers().cacheControl();

		http.headers().referrerPolicy(ReferrerPolicy.SAME_ORIGIN);

//		http.headers().xssProtection().and().contentSecurityPolicy("default-src 'self' 'unsafe-inline' 'nonce-{nonce}';"
//				+ "script-src  'self' ;style-src 'self'  'nonce-{nonce}'  ;"
//				+"object-src 'none'; base-uri 'self';font-src 'self'; frame-src 'self'; img-src  'self';"
//				+ "");

//		and().contentSecurityPolicy("default-src  'self';\r\n"
//				+ "		 		script-src  'self' 'unsafe-inline' 'nonce-{nonce}'  ; \r\n"
//				+ "				style-src 'self'  'nonce-{nonce}'  ; \r\n" + "				frame-ancestors 'none';\r\n"
//				+ "				object-src 'none'; base-uri 'self';\r\n" + "		 		connect-src 'self';\r\n"
//				+ "		  		font-src 'self'; frame-src 'self'; \r\n"
//				+ "		  		img-src  'self' https://mes.gov.in data: ; \r\n"
//				+ "		  		manifest-src 'self'; media-src 'self';");

//    	 http.sessionManagement().sessionCreationPolicy(SessionCreationPolicy.IF_REQUIRED)
//    	 .maximumSessions(1).expiredUrl("/login?logout")
//    	 .maxSessionsPreventsLogin(true)
//    	 .and()
//    	 .invalidSessionUrl("/login?logout").sessionFixation().migrateSession();
		http.authorizeRequests().antMatchers("/logout").permitAll();
		http.authorizeRequests().antMatchers("/schedule//taskdef1").permitAll();

//    	 http.authorizeRequests().antMatchers( "/login/**","/admin/**","AFMS/admin/**").permitAll();
		http.authorizeRequests().antMatchers("/login/**", "/admin/**").permitAll();

		http.authorizeRequests()
				.antMatchers("/auth/login_check?targetUrl", "/checkCapchaCode", "/SaveSpecializationData").permitAll();
		http.authorizeRequests().antMatchers("/genCapchaCode").permitAll();
//        http.authorizeRequests().antMatchers( "/AFMS/admin/LoadStudentForApproval").permitAll();

//        http.authorizeRequests().antMatchers( "/registrationUrl","/CheckEmailExistandSendEmail","/VerifyEmailandRegister","/admin/LoadStudentForApproval").permitAll();
		http.authorizeRequests().antMatchers("/registrationUrl", "/CheckEmailExistandSendEmail",
				"/VerifyEmailandRegister", "/Specialization").permitAll();

		http.authorizeRequests().and().exceptionHandling().accessDeniedPage("/403");
//        http.authorizeRequests().anyRequest().authenticated();
//        http.authorizeRequests().antMatchers("/**").permitAll();
		http.authorizeRequests().and().formLogin().usernameParameter("username").passwordParameter("password")
				.authenticationDetailsSource(extraParamSource).loginProcessingUrl("/auth/login_check")
				.loginPage("/login").successHandler(redirectLogin()).failureUrl("/login?error=true");
//        http
//        .logout(logout -> logout                                                
//            .logoutUrl("/logout")                                            
//            .logoutSuccessUrl("/login?logout")                                      
////            .logoutSuccessHandler(logoutSuccessHandler)                         
//            .invalidateHttpSession(true)                                        
////            .addLogoutHandler(logoutHandler)                                    
//            .deleteCookies("JSESSIONID")                                  
//        );
		http
//                .logout().logoutRequestMatcher(new AntPathRequestMatcher("/logout"))
//                .clearAuthentication(true).deleteCookies("JSESSIONID").invalidateHttpSession(true)
//                .logoutSuccessUrl("/login");
				.logout().logoutUrl("/logout").invalidateHttpSession(true).deleteCookies("JSESSIONID")
				.logoutSuccessUrl("/login?logout");
		http.sessionManagement().maximumSessions(1).maxSessionsPreventsLogin(true);
		http.sessionManagement().sessionFixation().migrateSession()
				.sessionAuthenticationStrategy(registerSessionAuthStr());
//                http.csrf().disable();

	}

	@Bean
	public SessionRegistry sessionRegistry() {
		SessionRegistry sessionRegistry = new SessionRegistryImpl();
		return sessionRegistry;
	}

	@Bean
	public RegisterSessionAuthenticationStrategy registerSessionAuthStr() {
		return new RegisterSessionAuthenticationStrategy(sessionRegistry());
	}

	@Bean
	public ServletListenerRegistrationBean<HttpSessionEventPublisher> httpSessionEventPublisher() {
		return new ServletListenerRegistrationBean<HttpSessionEventPublisher>(new HttpSessionEventPublisher());
	}

	@Bean
	public AuthenticationSuccessHandler redirectLogin() {
		return new redirectLogin();
	}
}