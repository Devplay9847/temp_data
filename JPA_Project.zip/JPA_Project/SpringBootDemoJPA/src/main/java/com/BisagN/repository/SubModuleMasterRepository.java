package com.BisagN.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.BisagN.models.TB_LDAP_MODULE_MASTER;
import com.BisagN.models.TB_LDAP_SUBMODULE_MASTER;

@Repository
public interface SubModuleMasterRepository extends JpaRepository<TB_LDAP_SUBMODULE_MASTER,Integer>{


	@Query("FROM TB_LDAP_SUBMODULE_MASTER U")
	public List<TB_LDAP_SUBMODULE_MASTER> LoadSubModuleData();

	@Query("FROM TB_LDAP_SUBMODULE_MASTER U where submodule_name = ?2 and module.id=?1")
	public List CheckSubModuleNameexist(int modulename, String submodname);
}
