package com.BisagN;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AfmsWithJpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(AfmsWithJpaApplication.class, args);
	}

}
