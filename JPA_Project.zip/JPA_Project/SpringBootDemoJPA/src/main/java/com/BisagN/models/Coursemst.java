/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.BisagN.models;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author rdp
 */
@Entity
@Table(name = "coursemst")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Coursemst.findAll", query = "SELECT c FROM Coursemst c"),
    @NamedQuery(name = "Coursemst.findByCid", query = "SELECT c FROM Coursemst c WHERE c.cid = :cid"),
    @NamedQuery(name = "Coursemst.findByNoofseats", query = "SELECT c FROM Coursemst c WHERE c.noofseats = :noofseats"),
    @NamedQuery(name = "Coursemst.findByCreateby", query = "SELECT c FROM Coursemst c WHERE c.createby = :createby"),
    @NamedQuery(name = "Coursemst.findByCreatedate", query = "SELECT c FROM Coursemst c WHERE c.createdate = :createdate"),
    @NamedQuery(name = "Coursemst.findByModifyby", query = "SELECT c FROM Coursemst c WHERE c.modifyby = :modifyby"),
    @NamedQuery(name = "Coursemst.findByModifydate", query = "SELECT c FROM Coursemst c WHERE c.modifydate = :modifydate"),
    @NamedQuery(name = "Coursemst.findByStatus", query = "SELECT c FROM Coursemst c WHERE c.status = :status"),
    @NamedQuery(name = "Coursemst.findByYear", query = "SELECT c FROM Coursemst c WHERE c.year = :year"),
    @NamedQuery(name = "Coursemst.findByP1seat", query = "SELECT c FROM Coursemst c WHERE c.p1seat = :p1seat"),
    @NamedQuery(name = "Coursemst.findByP2seat", query = "SELECT c FROM Coursemst c WHERE c.p2seat = :p2seat"),
    @NamedQuery(name = "Coursemst.findByP3seat", query = "SELECT c FROM Coursemst c WHERE c.p3seat = :p3seat"),
    @NamedQuery(name = "Coursemst.findByP4seat", query = "SELECT c FROM Coursemst c WHERE c.p4seat = :p4seat")})
public class Coursemst implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "cid")
    private Long cid;
    @Basic(optional = false)
    @Column(name = "noofseats")
    private int noofseats;
    @Basic(optional = false)
    @Column(name = "createby")
    private int createby;
    @Basic(optional = false)
    @Column(name = "createdate")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdate;
    @Column(name = "modifyby")
    private Integer modifyby;
    @Column(name = "modifydate")
    @Temporal(TemporalType.TIMESTAMP)
    private Date modifydate;
    @Column(name = "status")
    private Character status;
    @Column(name = "year")
    private String year;
    @Column(name = "p1seat")
    private Integer p1seat;
    @Column(name = "p2seat")
    private Integer p2seat;
    @Column(name = "p3seat")
    private Integer p3seat;
    @Column(name = "p4seat")
    private Integer p4seat;
    @JoinColumn(name = "inid", referencedColumnName = "inid")
    @ManyToOne(optional = false)
    private Institutemst inid;
    @JoinColumn(name = "sid", referencedColumnName = "sid")
    @ManyToOne
    private Specializationmst sid;

    public Coursemst() {
    }

    public Coursemst(Long cid) {
        this.cid = cid;
    }

    public Coursemst(Long cid, int noofseats, int createby, Date createdate) {
        this.cid = cid;
        this.noofseats = noofseats;
        this.createby = createby;
        this.createdate = createdate;
    }

    public Long getCid() {
        return cid;
    }

    public void setCid(Long cid) {
        this.cid = cid;
    }

    public int getNoofseats() {
        return noofseats;
    }

    public void setNoofseats(int noofseats) {
        this.noofseats = noofseats;
    }

    public int getCreateby() {
        return createby;
    }

    public void setCreateby(int createby) {
        this.createby = createby;
    }

    public Date getCreatedate() {
        return createdate;
    }

    public void setCreatedate(Date createdate) {
        this.createdate = createdate;
    }

    public Integer getModifyby() {
        return modifyby;
    }

    public void setModifyby(Integer modifyby) {
        this.modifyby = modifyby;
    }

    public Date getModifydate() {
        return modifydate;
    }

    public void setModifydate(Date modifydate) {
        this.modifydate = modifydate;
    }

    public Character getStatus() {
        return status;
    }

    public void setStatus(Character status) {
        this.status = status;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public Integer getP1seat() {
        return p1seat;
    }

    public void setP1seat(Integer p1seat) {
        this.p1seat = p1seat;
    }

    public Integer getP2seat() {
        return p2seat;
    }

    public void setP2seat(Integer p2seat) {
        this.p2seat = p2seat;
    }

    public Integer getP3seat() {
        return p3seat;
    }

    public void setP3seat(Integer p3seat) {
        this.p3seat = p3seat;
    }

    public Integer getP4seat() {
        return p4seat;
    }

    public void setP4seat(Integer p4seat) {
        this.p4seat = p4seat;
    }

    public Institutemst getInid() {
        return inid;
    }

    public void setInid(Institutemst inid) {
        this.inid = inid;
    }

    public Specializationmst getSid() {
        return sid;
    }

    public void setSid(Specializationmst sid) {
        this.sid = sid;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (cid != null ? cid.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Coursemst)) {
            return false;
        }
        Coursemst other = (Coursemst) object;
        if ((this.cid == null && other.cid != null) || (this.cid != null && !this.cid.equals(other.cid))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.mycompany.mavenproject1.Coursemst[ cid=" + cid + " ]";
    }
    
}
