package com.BisagN.service;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.BisagN.controller.AesUtil;

import javax.annotation.Nullable;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

/**
 * <p>
 * A custom Authentication provider example. To create custom
 * AuthenticationProvider, we need to implement the AuthenticationProvider
 * provide the implementation for the authenticate and support method.
 * </p>
 */
@Component
public class CustomAuthenticationProvider implements AuthenticationProvider {

	@Autowired
	UserDetailsServiceImpl userDetailsServiceImpl;

	BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

	/**
	 * <p>
	 * The authenticate method to authenticate the request. We will get the username
	 * from the Authentication object and will use the custom @userDetailsService
	 * service to load the given user.
	 * </p>
	 * 
	 * @param authentication
	 * @return
	 * @throws AuthenticationException
	 */
	@Override
	public Authentication authenticate(Authentication authentication) throws AuthenticationException {

		String salt = ((ExtraParam) authentication.getDetails()).getSalt();
		String iv = ((ExtraParam) authentication.getDetails()).getIv();
		String key = ((ExtraParam) authentication.getDetails()).getKey();
		int iterationCount = Integer.parseInt("1000");
		int keySize = Integer.parseInt("128");
		AesUtil aesUtil = new AesUtil(keySize, iterationCount);
		System.out.println("salt------------" + salt);

		String username = (authentication.getPrincipal() == null) ? "NONE_PROVIDED" : authentication.getName();
		if (StringUtils.isEmpty(username)) {
			throw new BadCredentialsException("invalid login details");
		}
		// get user details using Spring security user details service
		UserDetails user = null;
		try {
			username = aesUtil.decrypt(salt, iv, key, username);
			String password = aesUtil.decrypt(salt, iv, key, authentication.getCredentials().toString());
			user = userDetailsServiceImpl.loadUserByUsername(username);
			if (user == null) {
				throw new BadCredentialsException("invalid login details");
			} else {
				if (!passwordEncoder.matches(password, user.getPassword())) {
					throw new BadCredentialsException("Invalid Username and Password.");
				} else {

				}
			}

		} catch (UsernameNotFoundException exception) {
			throw new UsernameNotFoundException("USer Name Not Found");
		} catch (BadCredentialsException exception) {
			throw new BadCredentialsException("invalid login details");
		}
		return createSuccessfulAuthentication(authentication, user);
	}

	private Authentication createSuccessfulAuthentication(final Authentication authentication, final UserDetails user) {
		UsernamePasswordAuthenticationToken token = new UsernamePasswordAuthenticationToken(user.getUsername(),
				authentication.getCredentials(), user.getAuthorities());
		token.setDetails(authentication.getDetails());
		return token;
	}

//    @Override
//    public boolean supports(Class << ? > authentication) {
//        return authentication.equals(ExternalServiceAuthenticationToken.class);
//    }

	@Override
	public boolean supports(Class<?> authentication) {
		return (UsernamePasswordAuthenticationToken.class.isAssignableFrom(authentication));
	}

}
