package com.BisagN.Rbac.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.BisagN.controller.AES;
import com.BisagN.models.Role;
import com.BisagN.models.TB_LDAP_MODULE_MASTER;
import com.BisagN.models.TB_LDAP_ROLE_TYPE;
import com.BisagN.models.TB_LDAP_SUBMODULE_MASTER;
import com.BisagN.repository.ModuleMasterRepository;
import com.BisagN.repository.RoleRepository;
import com.BisagN.repository.RoleTypeRepository;
import com.BisagN.repository.SubModuleMasterRepository;

@Controller
public class SubModuleMaster {

	@Autowired
	ModuleMasterRepository moduleMasterRepository;

	@Autowired
	SubModuleMasterRepository subModuleMasterRepository;

	@RequestMapping(value = "/admin/SubModuleMaster", method = RequestMethod.GET)
	public ModelAndView SubModuleMaster() {
		ModelAndView model = new ModelAndView();
		model.setViewName("SubModuleMaster");
		return model;
	}

	@ResponseBody
	@RequestMapping(value = "/admin/getModuleName", method = RequestMethod.POST, produces = { "application/json" })
	public String getModuleName(HttpServletRequest request) {
		JSONArray jSONArray = new JSONArray();
		JSONObject object = new JSONObject();

		JSONObject object1 = new JSONObject();

		try {
			System.out.println("dsg");
			List<TB_LDAP_MODULE_MASTER> list1 = moduleMasterRepository.LoadModuleData();

			System.out.println("list1.size()" + list1.size());
			if (!list1.isEmpty()) {

				for (TB_LDAP_MODULE_MASTER tb_LDAP_MODULE_MASTER : list1) {
					object = new JSONObject();

					object.put("id", tb_LDAP_MODULE_MASTER.getId());
					object.put("name", tb_LDAP_MODULE_MASTER.getModule_name());
					jSONArray.add(object);
				}
				object1.put("modulelist", jSONArray);
			} else {
				jSONArray = new JSONArray();
				object1.put("modulelist", jSONArray);
			}

			object1.put("Status", "1");
			object1.put("Message", "Success");

		} catch (Exception e) {
			e.printStackTrace();
			object1 = new JSONObject();
			object1.put("Status", "0");
			object1.put("Message", "Something went wrong");
		}
		System.out.println("object1.toJSONString()" + object1.toJSONString());
		return object1.toJSONString();
	}

	@ResponseBody
	@RequestMapping(value = "/admin/LoadSubModuleMasterData", method = RequestMethod.POST, produces = {
			"application/json" })
	public String LoadSubModuleMasterData(HttpServletRequest request) {

		JSONObject jsonObject = new JSONObject();
		JSONArray jsonArray1 = new JSONArray();
		JSONParser jsonp = new JSONParser();
		JSONObject jsonobjectout = new JSONObject();
		String returnstring = "";
		try {
			// Add Server Side Validation TODO
			List<TB_LDAP_SUBMODULE_MASTER> sublist = subModuleMasterRepository.LoadSubModuleData();
			int counter = 1;
			for (TB_LDAP_SUBMODULE_MASTER submodule_MASTER : sublist) {

				JSONObject jsonObject2 = new JSONObject();
				jsonObject2.put("srno", "<span class='avtar avatar-blue'>" + counter + "</span>");
				jsonObject2.put("modulename", submodule_MASTER.getModule().getModule_name());
				jsonObject2.put("submodulename", submodule_MASTER.getSubmodule_name());

				jsonObject2.put("action", "<a href=\"#\" onclick=\"GetSubModuleData('"
						+ AES.encrypt(submodule_MASTER.getId() + "")
						+ "')\"><i class=\"fa fa-pencil\" aria-hidden=\"true\"></i></a> &nbsp;&nbsp; <a href=\"#\" onclick=\"DeleteSubModuleData('"
						+ AES.encrypt(submodule_MASTER.getId() + "")
						+ "')\"><i class=\"fa fa-trash\" aria-hidden=\"true\"></i></a>");
				jsonArray1.add(jsonObject2);
				counter++;
			}
			jsonobjectout.put("status", "1");
			jsonobjectout.put("data", jsonArray1);
			jsonobjectout.put("message", "Data Saved Successfully");
			returnstring = jsonobjectout.toJSONString();
		} catch (Exception e) {
			e.printStackTrace();
			jsonobjectout.put("status", "0");
			jsonobjectout.put("message", "Failure");
			returnstring = jsonobjectout.toJSONString();
		}
//		System.out.println("Output-->" + returnstring);

		return returnstring;
	}

	@ResponseBody
	@RequestMapping(value = "/admin/SaveSubModuleMasterData", method = RequestMethod.POST, produces = {
			"application/json" })
	public String SaveSubModuleMasterData(@RequestBody String data, HttpServletRequest request) {

		JSONObject jsonObject = new JSONObject();
		JSONArray jsonArray1 = new JSONArray();
		JSONParser jsonp = new JSONParser();
		JSONObject jsonobjectout = new JSONObject();
		String returnstring = "";
		try {
			// Add Server Side Validation TODO
			jsonObject = (JSONObject) jsonp.parse(data);

			String actiontype = jsonObject.get("actiontype").toString();

			String submodname = "";
			if (jsonObject.get("submodname") == null) {
				jsonobjectout.put("status", "0");
				jsonobjectout.put("message", "Please Enter Sub Module Name");
				return jsonobjectout.toJSONString();
			} else {
				submodname = jsonObject.get("submodname").toString().trim();
				if (submodname.length() < 2) {
					jsonobjectout.put("status", "0");
					jsonobjectout.put("message", "Sub Module Name must be of atleast 2 letters.");
					return jsonobjectout.toJSONString();
				} else {
					if (!submodname.matches("^[A-Za-z0-9 _]*[A-Za-z0-9][A-Za-z0-9 _]*$")) {
						jsonobjectout.put("status", "0");
						jsonobjectout.put("message", "Sub Module Name contains Letter and Digits only");
						return jsonobjectout.toJSONString();
					}
				}
			}

			String modulename = "";
			if (jsonObject.get("modulename") == null) {
				jsonobjectout.put("status", "0");
				jsonobjectout.put("message", "Please Select Module");
				return jsonobjectout.toJSONString();
			} else {
				modulename = jsonObject.get("modulename").toString().trim();
				if (modulename.equalsIgnoreCase("-1")) {
					jsonobjectout.put("status", "0");
					jsonobjectout.put("message", "Please Select Module");
					return jsonobjectout.toJSONString();
				}
			}

			boolean CheckSubmodulenameexist = false;
			List submoduleexistcheck = subModuleMasterRepository.CheckSubModuleNameexist(Integer.parseInt(modulename),
					submodname);
			if (actiontype.equalsIgnoreCase("add")) {
				if (submoduleexistcheck.isEmpty()) {
					CheckSubmodulenameexist = true;
				}
			} else {
				if (submoduleexistcheck.isEmpty() || submoduleexistcheck.size() == 1) {
					CheckSubmodulenameexist = true;
				}
			}
			if (CheckSubmodulenameexist) {

				TB_LDAP_SUBMODULE_MASTER tb_LDAP_SUBMODULE_MASTER = new TB_LDAP_SUBMODULE_MASTER();
				tb_LDAP_SUBMODULE_MASTER.setSubmodule_name(submodname);

				TB_LDAP_MODULE_MASTER tb_LDAP_MODULE_MASTER = new TB_LDAP_MODULE_MASTER();
				tb_LDAP_MODULE_MASTER.setId(Integer.parseInt(modulename));

				tb_LDAP_SUBMODULE_MASTER.setModule(tb_LDAP_MODULE_MASTER);

				if (actiontype.equalsIgnoreCase("add")) {

					subModuleMasterRepository.save(tb_LDAP_SUBMODULE_MASTER);
					jsonobjectout.put("message", "Data Saved Successfully");
					jsonobjectout.put("status", "1");

					returnstring = jsonobjectout.toJSONString();
				} else {

					TB_LDAP_SUBMODULE_MASTER submodule_MASTER = subModuleMasterRepository
							.getById(Integer.parseInt(jsonObject.get("submoduleid").toString()));
					if (submodule_MASTER != null) {
						submodule_MASTER.setSubmodule_name(submodname);

						tb_LDAP_MODULE_MASTER = new TB_LDAP_MODULE_MASTER();
						tb_LDAP_MODULE_MASTER.setId(Integer.parseInt(modulename));

						submodule_MASTER.setModule(tb_LDAP_MODULE_MASTER);
						subModuleMasterRepository.save(submodule_MASTER);
						jsonobjectout.put("message", "Data updated Successfully");
						jsonobjectout.put("status", "1");

						returnstring = jsonobjectout.toJSONString();
					} else {
						jsonobjectout.put("status", "0");
						jsonobjectout.put("message", "Role ID Not Found");
						returnstring = jsonobjectout.toJSONString();
					}

				}

			} else {
				jsonobjectout.put("status", "0");
				jsonobjectout.put("message", "Sub Module Name already exist");
				returnstring = jsonobjectout.toJSONString();
			}

		} catch (Exception e) {
			e.printStackTrace();
			jsonobjectout.put("status", "0");
			jsonobjectout.put("message", "Failure");
			returnstring = jsonobjectout.toJSONString();
		}
		System.out.println("Output-->" + returnstring);

		return returnstring;
	}

	@ResponseBody
	@RequestMapping(value = "/admin/SaveSubModuleMasterData1", method = RequestMethod.POST, produces = {
			"application/json" })
	public String SaveSubModuleMasterData1(@RequestBody TB_LDAP_SUBMODULE_MASTER tb_LDAP_SUBMODULE_MASTER,
			HttpServletRequest request) {
		System.out.println("1");
		JSONObject jsonObject = new JSONObject();
		JSONArray jsonArray1 = new JSONArray();
		JSONParser jsonp = new JSONParser();
		JSONObject jsonobjectout = new JSONObject();
		String returnstring = "Success";
		try {
			// Add Server Side Validation TODO
			System.out.println("tb_LDAP_SUBMODULE_MASTER" + tb_LDAP_SUBMODULE_MASTER.getSubmodule_name());
		} catch (Exception e) {
			e.printStackTrace();
			jsonobjectout.put("status", "0");
			jsonobjectout.put("message", "Failure");
			returnstring = jsonobjectout.toJSONString();
		}
		System.out.println("Output-->" + returnstring);

		return returnstring;
	}

	@ResponseBody
	@RequestMapping(value = "/admin/DeleteSubModuleData", method = RequestMethod.POST, produces = {
			"application/json" })
	public String DeleteSubModuleData(@RequestBody String data, HttpServletRequest request) {

		JSONObject jsonObject = new JSONObject();
		JSONArray jsonArray1 = new JSONArray();
		JSONParser jsonp = new JSONParser();
		JSONObject jsonobjectout = new JSONObject();
		String returnstring = "";
		try {
			// Add Server Side Validation TODO
			jsonObject = (JSONObject) jsonp.parse(data);
			if (jsonObject.get("submoduleid") != null) {

				int submoduleid = Integer.parseInt(AES.decrypt(jsonObject.get("submoduleid").toString()));
				TB_LDAP_SUBMODULE_MASTER tb_LDAP_SUBMODULE_MASTER = subModuleMasterRepository.getById(submoduleid);
				if (tb_LDAP_SUBMODULE_MASTER != null) {
					subModuleMasterRepository.delete(tb_LDAP_SUBMODULE_MASTER);
					jsonobjectout.put("status", "1");
					jsonobjectout.put("message", "Data Deleted Successfully");
					returnstring = jsonobjectout.toJSONString();
				} else {
					jsonobjectout.put("status", "0");
					jsonobjectout.put("message", "No Data Found");
					returnstring = jsonobjectout.toJSONString();
				}

			} else {
				jsonobjectout.put("status", "0");
				jsonobjectout.put("message", "No Data Found");
				returnstring = jsonobjectout.toJSONString();
			}

		} catch (Exception e) {
			e.printStackTrace();
			jsonobjectout.put("status", "0");
			jsonobjectout.put("message", "Failure");
			returnstring = jsonobjectout.toJSONString();
		}
//		System.out.println("Output-->" + returnstring);

		return returnstring;
	}

	@ResponseBody
	@RequestMapping(value = "/admin/GetSubModuleDataForUpdate", method = RequestMethod.POST, produces = {
			"application/json" })
	public String GetSubModuleDataForUpdate(@RequestBody String data, HttpServletRequest request) {

		JSONObject jsonObject = new JSONObject();
		JSONArray jsonArray1 = new JSONArray();
		JSONParser jsonp = new JSONParser();
		JSONObject jsonobjectout = new JSONObject();
		String returnstring = "";
		try {
			// Add Server Side Validation TODO
			jsonObject = (JSONObject) jsonp.parse(data);
			if (jsonObject.get("submoduleid") != null) {

				int submoduleid = Integer.parseInt(AES.decrypt(jsonObject.get("submoduleid").toString()));

				TB_LDAP_SUBMODULE_MASTER tb_LDAP_SUBMODULE_MASTER = subModuleMasterRepository.getById(submoduleid);
				if (tb_LDAP_SUBMODULE_MASTER != null) {
					jsonobjectout.put("status", "1");
					jsonobjectout.put("submodname", tb_LDAP_SUBMODULE_MASTER.getSubmodule_name());
					jsonobjectout.put("modulename", tb_LDAP_SUBMODULE_MASTER.getModule().getId());

					jsonobjectout.put("submoduleid", tb_LDAP_SUBMODULE_MASTER.getId());
					returnstring = jsonobjectout.toJSONString();
				} else {
					jsonobjectout.put("status", "0");
					jsonobjectout.put("message", "No Data Found");
					returnstring = jsonobjectout.toJSONString();
				}

			} else {
				jsonobjectout.put("status", "0");
				jsonobjectout.put("message", "No Data Found");
				returnstring = jsonobjectout.toJSONString();
			}

		} catch (Exception e) {
			e.printStackTrace();
			jsonobjectout.put("status", "0");
			jsonobjectout.put("message", "Failure");
			returnstring = jsonobjectout.toJSONString();
		}
		System.out.println("Output-->" + returnstring);

		return returnstring;
	}

}
