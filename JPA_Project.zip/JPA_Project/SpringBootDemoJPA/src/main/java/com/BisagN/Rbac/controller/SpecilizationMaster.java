package com.BisagN.Rbac.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import javax.persistence.Column;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import org.apache.commons.collections4.MapUtils;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;
import com.BisagN.models.Specializationmst;
import com.BisagN.repository.SpecilizationRepository;

@RestController
public class SpecilizationMaster {

	@Autowired
	SpecilizationRepository speciliaztionr;

	@RequestMapping(value = "/admin/Specialization", method = RequestMethod.GET)
	public ModelAndView Specialization() {
		ModelAndView model = new ModelAndView();
		model.setViewName("Specialization");
		return model;
	}

	@RequestMapping(value = "/admin/SaveSpecializationData", method = RequestMethod.POST, produces = {
			"application/json" })
	public String SaveSpecializationData(@Valid @RequestBody Specializationmst specializationmst,
			HttpServletRequest request) {

		String returnstring = "";
		JSONObject jsonobjectout = new JSONObject();
		try {

			String sessionuserid = request.getSession().getAttribute("userId_for_jnlp").toString();
			if (specializationmst.getSid() != null && specializationmst.getSid() != 0) {
				Optional<Specializationmst> specializationmstd = speciliaztionr.findById(specializationmst.getSid());
				if (specializationmstd != null) {
					Specializationmst specializationmst2 = specializationmstd.get();

					specializationmst.setStatus(specializationmst2.getStatus());
					specializationmst.setCreateby(specializationmst2.getCreateby());
					specializationmst.setCreatedate(specializationmst2.getCreatedate());
					specializationmst.setModifyby(Integer.parseInt(sessionuserid));
					specializationmst.setModifydate(new Date());
					speciliaztionr.save(specializationmst);
					jsonobjectout.put("status", "1");
					jsonobjectout.put("message", "Details updated Successfully");
					returnstring = jsonobjectout.toJSONString();
				} else {
					jsonobjectout.put("status", "0");
					jsonobjectout.put("message", "Please Select The Id For Update");
					returnstring = jsonobjectout.toJSONString();
				}
			} else {
				specializationmst.setStatus('1');
				specializationmst.setCreateby(Integer.parseInt(sessionuserid));
				specializationmst.setCreatedate(new Date());
				speciliaztionr.save(specializationmst);
				jsonobjectout.put("status", "1");
				jsonobjectout.put("message", "Details added Successfully");
				returnstring = jsonobjectout.toJSONString();
			}

		} catch (Exception e) {
			e.printStackTrace();
			jsonobjectout.put("status", "1");
			jsonobjectout.put("message", e.getMessage());
			returnstring = jsonobjectout.toJSONString();
		}
		System.out.println("Output-->" + returnstring);

		return returnstring;
	}

	@ResponseBody
	@RequestMapping(value = "/admin/LoadSpecializationData", method = RequestMethod.POST, produces = {
			"application/json" })
	public String LoadSpecializationData(HttpServletRequest request, @RequestParam int pageno, @RequestParam int length,
			String search) {

		JSONObject jsonObject = new JSONObject();
		JSONArray jsonArray1 = new JSONArray();
		JSONParser jsonp = new JSONParser();
		JSONObject jsonobjectout = new JSONObject();
		String returnstring = "";
		try {
			// Add Server Side Validation TODO
			System.out.println("pageno" + pageno + "search" + search);
			List<String> Columns = new ArrayList<String>();
			Pageable pageable = PageRequest.of(pageno, length);
			Page<Specializationmst> specializationmsts = speciliaztionr.LoadSpecializationData(pageable);
			Set<Specializationmst> specializationmstsd1 =	specializationmsts.toSet();
			
			Iterator<Specializationmst> namesIterator = specializationmstsd1.iterator();
			
			while(namesIterator.hasNext()) {
				   System.out.println(namesIterator.next());
				}
			 
			 int count = (int) specializationmsts.getPageable().getOffset();
			count = count + 1;
			List<Specializationmst> specializationmstsd = specializationmsts.getContent();
			
			
//			Map<String, Specializationmst> map = 
//					specializationmstsd.stream().collect(Collectors.toMap(specializationmstsd::getKey, item -> specializationmstsd));
//
//			java.lang.reflect.Field[] fields1 = specializationmstsd.getClass().getDeclaredFields();
//			  for (java.lang.reflect.Field field : fields1) {
//		            Column col = field.getAnnotation(Column.class);
//		            
//		            if (col != null) {
//		                Columns.add(col.name());
//		                System.out.println("Columns: "+col);
//		            }
//		         }

			/*Map<Integer, String> result1 = specializationmstsd.stream()
					.collect(Collectors.toMap(Specializationmst::getSid, Specializationmst::getSpecializationname));

			Map<Integer, String> result3 = specializationmstsd.stream()
					.collect(Collectors.toMap(x -> x.getSid(), x -> x.getSpecializationname()));

			System.out.println("result1" + result1.toString());
			System.out.println("result1" + result3.toString());

			Map<Integer, Specializationmst> map = new HashMap<>();
			MapUtils.populateMap(map, specializationmstsd, Specializationmst::getSid);

			System.out.println("Value list: " + map.toString());*/
	        java.lang.reflect.Field[] fields =  specializationmstsd.get(0).getClass().getDeclaredFields();
	        for (java.lang.reflect.Field field : fields) {
	           // Column col = field.getAnnotation(Column.class);
	            //System.out.println(field.getAnnotation(Column.class).name());
	        	//if (col != null) {
	                Columns.add(field.getAnnotation(Column.class).name());
	  //              System.out.println("Columns: "+col.name());
	    //        }
	         }
	        System.out.println("============"+ Columns.get(0));
	        
	        for (int i = 0; i < specializationmstsd.size(); i++) {
	        	Specializationmst specializationmst = specializationmstsd.get(i);
		        Map<String, Object> columns = new LinkedHashMap<String, Object>();
		        for (int j = 1; j <= Columns.size(); j++) {
				    columns.put(Columns.get(i), specializationmst.getClass().getName());
				    System.out.println("=======:====="+specializationmst.getClass().getName());
				}
	        }
	        
				/*
				 * for(int i=0;i<Columns.size();i++) { String
				 * System.out.println("Columns: "+Columns[i]); }
				 */
			for (int i = 0; i < specializationmstsd.size(); i++) {
				
				Specializationmst specializationmst = specializationmstsd.get(i);
				JSONObject jsonObject2 = new JSONObject();
				jsonObject2.put("srno", "<span class='avtar avatar-blue'>" + count + "</span>");
				jsonObject2.put("name", specializationmst.getSpecializationname());
				jsonObject2.put("year", specializationmst.getYear());

				jsonObject2.put("action", "<a href=\"#\" onclick=\"GetSpecializationData(" + specializationmst.getSid()
						+ ")\"><i class=\"fa fa-pencil\" aria-hidden=\"true\"></i></a> &nbsp;&nbsp; <a href=\"#\" onclick=\"DeleteDocumentData("
						+ specializationmst.getSid() + ")\"><i class=\"fa fa-trash\" aria-hidden=\"true\"></i></a>");
				jsonArray1.add(jsonObject2);
				count++;

			}
			jsonobjectout.put("status", "1");
			jsonobjectout.put("data", jsonArray1);
			jsonobjectout.put("message", "Data Load Successfully");
			jsonobjectout.put("TotalCount", specializationmsts.getTotalElements());
			returnstring = jsonobjectout.toJSONString();

		} catch (Exception e) {
			e.printStackTrace();
			jsonobjectout.put("status", "0");
			jsonobjectout.put("message", "Failure");
			returnstring = jsonobjectout.toJSONString();
		}
		System.out.println("Output-->" + returnstring);

		return returnstring;
	}

	@ResponseBody
	@RequestMapping(value = "/admin/GetSpecializationDataForUpdate", method = RequestMethod.POST, produces = {
			"application/json" })
	public String GetSpecializationDataForUpdate(@RequestBody String data, HttpServletRequest request) {

		JSONObject jsonObject = new JSONObject();
		JSONArray jsonArray1 = new JSONArray();
		JSONParser jsonp = new JSONParser();
		JSONObject jsonobjectout = new JSONObject();
		String returnstring = "";
		try {
			// Add Server Side Validation TODO
			jsonObject = (JSONObject) jsonp.parse(data);
			if (jsonObject.get("sid") != null) {

				int sid = Integer.parseInt(jsonObject.get("sid").toString());
				Specializationmst specializationmst = new Specializationmst();
				Optional<Specializationmst> specializationmstopt = speciliaztionr.findById(sid);
				if (specializationmstopt != null) {
					specializationmst = specializationmstopt.get();
					jsonobjectout.put("status", "1");

					jsonobjectout.put("coursename", specializationmst.getSpecializationname());
					jsonobjectout.put("sid", specializationmst.getSid());

					returnstring = jsonobjectout.toJSONString();
				} else {
					jsonobjectout.put("status", "0");
					jsonobjectout.put("message", "No Data Found");
					returnstring = jsonobjectout.toJSONString();
				}

			} else {
				jsonobjectout.put("status", "0");
				jsonobjectout.put("message", "No Data Found");
				returnstring = jsonobjectout.toJSONString();
			}

		} catch (Exception e) {
			e.printStackTrace();
			jsonobjectout.put("status", "0");
			jsonobjectout.put("message", "Failure");
			returnstring = jsonobjectout.toJSONString();
		}
		System.out.println("Output-->" + returnstring);

		return returnstring;
	}

	@ResponseBody
	@RequestMapping(value = "/admin/DeleteSpecialiaztionData", method = RequestMethod.POST, produces = {
			"application/json" })
	public String DeleteSpecialiaztionData(@RequestBody String data, HttpServletRequest request) {

		JSONObject jsonObject = new JSONObject();
		JSONArray jsonArray1 = new JSONArray();
		JSONParser jsonp = new JSONParser();
		JSONObject jsonobjectout = new JSONObject();
		String returnstring = "";
		try {
			// Add Server Side Validation TODO
			jsonObject = (JSONObject) jsonp.parse(data);
			if (jsonObject.get("sid") != null) {

				int sid = Integer.parseInt(jsonObject.get("sid").toString());
				Optional<Specializationmst> specializationmst = speciliaztionr.findById(sid);

				if (specializationmst != null) {
					Specializationmst specializationmst2 = specializationmst.get();
					specializationmst2.setStatus('0');
					specializationmst2.setModifyby(null);
					specializationmst2.setModifydate(new Date());
					speciliaztionr.save(specializationmst2);
					jsonobjectout.put("status", "1");
					jsonobjectout.put("message", "Data Deleted Successfully");
					returnstring = jsonobjectout.toJSONString();
				} else {
					jsonobjectout.put("status", "0");
					jsonobjectout.put("message", "No Data Found");
					returnstring = jsonobjectout.toJSONString();
				}

			} else {
				jsonobjectout.put("status", "0");
				jsonobjectout.put("message", "No Data Found");
				returnstring = jsonobjectout.toJSONString();
			}

		} catch (Exception e) {
			e.printStackTrace();
			jsonobjectout.put("status", "0");
			jsonobjectout.put("message", "Failure");
			returnstring = jsonobjectout.toJSONString();
		}
		System.out.println("Output-->" + returnstring);

		return returnstring;
	}

	//@SuppressWarnings("unchecked")
	@ResponseStatus(HttpStatus.BAD_REQUEST)
	@ExceptionHandler(MethodArgumentNotValidException.class)
	public String handleValidationExceptions(MethodArgumentNotValidException ex) {
		JSONArray jsonArray = new JSONArray();
		JSONObject jsonObject = new JSONObject();
		ex.getBindingResult().getAllErrors().forEach((error) -> {
			String fieldName = ((FieldError) error).getField();
			String errorMessage = error.getDefaultMessage();
			JSONObject jsonObject1 = new JSONObject();
			jsonObject1.put(fieldName, errorMessage);
			jsonArray.add(jsonObject1);
		});
		jsonObject.put("status", "0");
		jsonObject.put("message", jsonArray.toJSONString());
		return jsonArray.toJSONString();
	}

}
