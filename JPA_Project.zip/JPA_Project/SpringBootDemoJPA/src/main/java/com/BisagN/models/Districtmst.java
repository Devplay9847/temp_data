/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.BisagN.models;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author rdp
 */
@Entity
@Table(name = "districtmst")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Districtmst.findAll", query = "SELECT d FROM Districtmst d"),
    @NamedQuery(name = "Districtmst.findByDid", query = "SELECT d FROM Districtmst d WHERE d.did = :did"),
    @NamedQuery(name = "Districtmst.findByDistrictname", query = "SELECT d FROM Districtmst d WHERE d.districtname = :districtname"),
    @NamedQuery(name = "Districtmst.findByStatus", query = "SELECT d FROM Districtmst d WHERE d.status = :status"),
    @NamedQuery(name = "Districtmst.findByCreateby", query = "SELECT d FROM Districtmst d WHERE d.createby = :createby"),
    @NamedQuery(name = "Districtmst.findByCreatedate", query = "SELECT d FROM Districtmst d WHERE d.createdate = :createdate"),
    @NamedQuery(name = "Districtmst.findByModifyby", query = "SELECT d FROM Districtmst d WHERE d.modifyby = :modifyby"),
    @NamedQuery(name = "Districtmst.findByModifydate", query = "SELECT d FROM Districtmst d WHERE d.modifydate = :modifydate")})
public class Districtmst implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "did")
    private Integer did;
    @Basic(optional = false)
    @Column(name = "districtname")
    private String districtname;
    @Basic(optional = false)
    @Column(name = "status")
    private Character status;
    @Basic(optional = false)
    @Column(name = "createby")
    private int createby;
    @Basic(optional = false)
    @Column(name = "createdate")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdate;
    @Column(name = "modifyby")
    private Integer modifyby;
    @Column(name = "modifydate")
    @Temporal(TemporalType.TIMESTAMP)
    private Date modifydate;
    @JoinColumn(name = "cid", referencedColumnName = "cid")
    @ManyToOne(optional = false)
    private Countrymst cid;
    @JoinColumn(name = "sid", referencedColumnName = "sid")
    @ManyToOne(optional = false)
    private Statemaster sid;

    public Districtmst() {
    }

    public Districtmst(Integer did) {
        this.did = did;
    }

    public Districtmst(Integer did, String districtname, Character status, int createby, Date createdate) {
        this.did = did;
        this.districtname = districtname;
        this.status = status;
        this.createby = createby;
        this.createdate = createdate;
    }

    public Integer getDid() {
        return did;
    }

    public void setDid(Integer did) {
        this.did = did;
    }

    public String getDistrictname() {
        return districtname;
    }

    public void setDistrictname(String districtname) {
        this.districtname = districtname;
    }

    public Character getStatus() {
        return status;
    }

    public void setStatus(Character status) {
        this.status = status;
    }

    public int getCreateby() {
        return createby;
    }

    public void setCreateby(int createby) {
        this.createby = createby;
    }

    public Date getCreatedate() {
        return createdate;
    }

    public void setCreatedate(Date createdate) {
        this.createdate = createdate;
    }

    public Integer getModifyby() {
        return modifyby;
    }

    public void setModifyby(Integer modifyby) {
        this.modifyby = modifyby;
    }

    public Date getModifydate() {
        return modifydate;
    }

    public void setModifydate(Date modifydate) {
        this.modifydate = modifydate;
    }

    public Countrymst getCid() {
        return cid;
    }

    public void setCid(Countrymst cid) {
        this.cid = cid;
    }

    public Statemaster getSid() {
        return sid;
    }

    public void setSid(Statemaster sid) {
        this.sid = sid;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (did != null ? did.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Districtmst)) {
            return false;
        }
        Districtmst other = (Districtmst) object;
        if ((this.did == null && other.did != null) || (this.did != null && !this.did.equals(other.did))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.mycompany.mavenproject1.Districtmst[ did=" + did + " ]";
    }
    
}
