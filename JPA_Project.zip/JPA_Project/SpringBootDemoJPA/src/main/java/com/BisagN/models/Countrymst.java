/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.BisagN.models;

import java.io.Serializable;
import java.util.Collection;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author rdp
 */
@Entity
@Table(name = "countrymst")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Countrymst.findAll", query = "SELECT c FROM Countrymst c"),
    @NamedQuery(name = "Countrymst.findByCid", query = "SELECT c FROM Countrymst c WHERE c.cid = :cid"),
    @NamedQuery(name = "Countrymst.findByCountryname", query = "SELECT c FROM Countrymst c WHERE c.countryname = :countryname"),
    @NamedQuery(name = "Countrymst.findByCreaetby", query = "SELECT c FROM Countrymst c WHERE c.creaetby = :creaetby"),
    @NamedQuery(name = "Countrymst.findByCreatedate", query = "SELECT c FROM Countrymst c WHERE c.createdate = :createdate"),
    @NamedQuery(name = "Countrymst.findByModifyby", query = "SELECT c FROM Countrymst c WHERE c.modifyby = :modifyby"),
    @NamedQuery(name = "Countrymst.findByModifydate", query = "SELECT c FROM Countrymst c WHERE c.modifydate = :modifydate"),
    @NamedQuery(name = "Countrymst.findByStatus", query = "SELECT c FROM Countrymst c WHERE c.status = :status")})
public class Countrymst implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "cid")
    private Integer cid;
    @Basic(optional = false)
    @Column(name = "countryname")
    private String countryname;
    @Basic(optional = false)
    @Column(name = "creaetby")
    private int creaetby;
    @Basic(optional = false)
    @Column(name = "createdate")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdate;
    @Column(name = "modifyby")
    private Integer modifyby;
    @Column(name = "modifydate")
    @Temporal(TemporalType.TIMESTAMP)
    private Date modifydate;
    @Basic(optional = false)
    @Column(name = "status")
    private Character status;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "cid")
    private Collection<Districtmst> districtmstCollection;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "cid")
    private Collection<Statemaster> statemasterCollection;

    public Countrymst() {
    }

    public Countrymst(Integer cid) {
        this.cid = cid;
    }

    public Countrymst(Integer cid, String countryname, int creaetby, Date createdate, Character status) {
        this.cid = cid;
        this.countryname = countryname;
        this.creaetby = creaetby;
        this.createdate = createdate;
        this.status = status;
    }

    public Integer getCid() {
        return cid;
    }

    public void setCid(Integer cid) {
        this.cid = cid;
    }

    public String getCountryname() {
        return countryname;
    }

    public void setCountryname(String countryname) {
        this.countryname = countryname;
    }

    public int getCreaetby() {
        return creaetby;
    }

    public void setCreaetby(int creaetby) {
        this.creaetby = creaetby;
    }

    public Date getCreatedate() {
        return createdate;
    }

    public void setCreatedate(Date createdate) {
        this.createdate = createdate;
    }

    public Integer getModifyby() {
        return modifyby;
    }

    public void setModifyby(Integer modifyby) {
        this.modifyby = modifyby;
    }

    public Date getModifydate() {
        return modifydate;
    }

    public void setModifydate(Date modifydate) {
        this.modifydate = modifydate;
    }

    public Character getStatus() {
        return status;
    }

    public void setStatus(Character status) {
        this.status = status;
    }

    @XmlTransient
    public Collection<Districtmst> getDistrictmstCollection() {
        return districtmstCollection;
    }

    public void setDistrictmstCollection(Collection<Districtmst> districtmstCollection) {
        this.districtmstCollection = districtmstCollection;
    }

    @XmlTransient
    public Collection<Statemaster> getStatemasterCollection() {
        return statemasterCollection;
    }

    public void setStatemasterCollection(Collection<Statemaster> statemasterCollection) {
        this.statemasterCollection = statemasterCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (cid != null ? cid.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Countrymst)) {
            return false;
        }
        Countrymst other = (Countrymst) object;
        if ((this.cid == null && other.cid != null) || (this.cid != null && !this.cid.equals(other.cid))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.mycompany.mavenproject1.Countrymst[ cid=" + cid + " ]";
    }
    
}
