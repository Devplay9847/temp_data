/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.BisagN.models;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author rdp
 */
@Entity
@Table(name = "specializationmst")
@XmlRootElement
@NamedQueries({ @NamedQuery(name = "Specializationmst.findAll", query = "SELECT s FROM Specializationmst s"),
		@NamedQuery(name = "Specializationmst.findBySid", query = "SELECT s FROM Specializationmst s WHERE s.sid = :sid"),
		@NamedQuery(name = "Specializationmst.findBySpecializationname", query = "SELECT s FROM Specializationmst s WHERE s.specializationname = :specializationname"),
		@NamedQuery(name = "Specializationmst.findByModifyby", query = "SELECT s FROM Specializationmst s WHERE s.modifyby = :modifyby"),
		@NamedQuery(name = "Specializationmst.findByModifydate", query = "SELECT s FROM Specializationmst s WHERE s.modifydate = :modifydate"),
		@NamedQuery(name = "Specializationmst.findByStatus", query = "SELECT s FROM Specializationmst s WHERE s.status = :status"),
		@NamedQuery(name = "Specializationmst.findByYear", query = "SELECT s FROM Specializationmst s WHERE s.year = :year"),
		@NamedQuery(name = "Specializationmst.findByCreateby", query = "SELECT s FROM Specializationmst s WHERE s.createby = :createby"),
		@NamedQuery(name = "Specializationmst.findByCreatedate", query = "SELECT s FROM Specializationmst s WHERE s.createdate = :createdate") })
public class Specializationmst implements Serializable {

	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Basic(optional = false)
	@Column(name = "sid")
	private Integer sid;
	@Basic(optional = false)
	@NotNull(message = "specializationname is mandatory")
	@NotBlank(message = "specializationname is mandatory")
	@Column(name = "specializationname")
	private String specializationname;
	@Column(name = "modifyby")
	private Integer modifyby;
	@Column(name = "modifydate")
	@Temporal(TemporalType.TIMESTAMP)
	private Date modifydate;
	@Basic(optional = false)
	@Column(name = "status")
	private Character status;
	@Basic(optional = false)
	@NotNull(message = "year is mandatory")
	@NotBlank(message = "year is mandatory")
	@Column(name = "year")
	private String year;
	@Basic(optional = false)
	@Column(name = "createby")
	private int createby;
	@Basic(optional = false)
	@Column(name = "createdate")
	@Temporal(TemporalType.TIMESTAMP)
	private Date createdate;

	public Specializationmst() {
	}

	public Specializationmst(Integer sid) {
		this.sid = sid;
	}

	public Specializationmst(Integer sid, String specializationname, Character status, String year, int createby,
			Date createdate) {
		this.sid = sid;
		this.specializationname = specializationname;
		this.status = status;
		this.year = year;
		this.createby = createby;
		this.createdate = createdate;
	}

	public Integer getSid() {
		return sid;
	}

	public void setSid(Integer sid) {
		this.sid = sid;
	}

	public String getSpecializationname() {
		return specializationname;
	}

	public void setSpecializationname(String specializationname) {
		this.specializationname = specializationname;
	}

	public Integer getModifyby() {
		return modifyby;
	}

	public void setModifyby(Integer modifyby) {
		this.modifyby = modifyby;
	}

	public Date getModifydate() {
		return modifydate;
	}

	public void setModifydate(Date modifydate) {
		this.modifydate = modifydate;
	}

	public Character getStatus() {
		return status;
	}

	public void setStatus(Character status) {
		this.status = status;
	}

	public String getYear() {
		return year;
	}

	public void setYear(String year) {
		this.year = year;
	}

	public int getCreateby() {
		return createby;
	}

	public void setCreateby(int createby) {
		this.createby = createby;
	}

	public Date getCreatedate() {
		return createdate;
	}

	public void setCreatedate(Date createdate) {
		this.createdate = createdate;
	}

	@Override
	public int hashCode() {
		int hash = 0;
		hash += (sid != null ? sid.hashCode() : 0);
		return hash;
	}

	@Override
	public boolean equals(Object object) {
		// TODO: Warning - this method won't work in the case the id fields are not set
		if (!(object instanceof Specializationmst)) {
			return false;
		}
		Specializationmst other = (Specializationmst) object;
		if ((this.sid == null && other.sid != null) || (this.sid != null && !this.sid.equals(other.sid))) {
			return false;
		}
		return true;
	}

	@Override
	public String toString() {
		return "com.mycompany.mavenproject1.Specializationmst[ sid=" + sid + " ]";
	}

}
