package com.BisagN.Rbac.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.BisagN.controller.AES;
import com.BisagN.models.TB_LDAP_MODULE_MASTER;
import com.BisagN.repository.ModuleMasterRepository;

@Controller
public class ModuleMasterController {

	@Autowired
	ModuleMasterRepository moduleMasterRepository;

	@RequestMapping(value = "/admin/ModuleMaster", method = RequestMethod.GET)
	public ModelAndView ModuleMaster() {
		ModelAndView model = new ModelAndView();
		model.setViewName("ModuleMaster");
		return model;
	}

	@ResponseBody
	@RequestMapping(value = "/admin/LoadModuleMasterData", method = RequestMethod.POST, produces = {
			"application/json" })
	public String LoadModuleMasterData(HttpServletRequest request) {

		JSONObject jsonObject = new JSONObject();
		JSONArray jsonArray1 = new JSONArray();
		JSONParser jsonp = new JSONParser();
		JSONObject jsonobjectout = new JSONObject();
		String returnstring = "";
		try {
			// Add Server Side Validation TODO
			List<TB_LDAP_MODULE_MASTER> modulelist = moduleMasterRepository.LoadModuleData();
			int counter = 1;
			for (TB_LDAP_MODULE_MASTER tb_LDAP_MODULE_MASTER : modulelist) {

				JSONObject jsonObject2 = new JSONObject();
				jsonObject2.put("srno", "<span class='avtar avatar-blue'>" + counter + "</span>");
				jsonObject2.put("modulename", tb_LDAP_MODULE_MASTER.getModule_name());

				jsonObject2.put("action", "<a href=\"#\" onclick=\"GetModuleData('"
						+ AES.encrypt(tb_LDAP_MODULE_MASTER.getId() + "")
						+ "')\"><i class=\"fa fa-pencil\" aria-hidden=\"true\"></i></a> &nbsp;&nbsp; <a href=\"#\" onclick=\"DeleteModuleData('"
						+ AES.encrypt(tb_LDAP_MODULE_MASTER.getId() + "")
						+ "')\"><i class=\"fa fa-trash\" aria-hidden=\"true\"></i></a>");
				jsonArray1.add(jsonObject2);
				counter++;
			}
			jsonobjectout.put("status", "1");
			jsonobjectout.put("data", jsonArray1);
			jsonobjectout.put("message", "Data Saved Successfully");
			returnstring = jsonobjectout.toJSONString();
		} catch (Exception e) {
			e.printStackTrace();
			jsonobjectout.put("status", "0");
			jsonobjectout.put("message", "Failure");
			returnstring = jsonobjectout.toJSONString();
		}
//		System.out.println("Output-->" + returnstring);

		return returnstring;
	}

	@ResponseBody
	@RequestMapping(value = "/admin/SaveModuleMasterData", method = RequestMethod.POST, produces = {
			"application/json" })
	public String SaveModuleMasterData(@RequestBody String data, HttpServletRequest request) {

		JSONObject jsonObject = new JSONObject();
		JSONArray jsonArray1 = new JSONArray();
		JSONParser jsonp = new JSONParser();
		JSONObject jsonobjectout = new JSONObject();
		String returnstring = "";
		try {
			// Add Server Side Validation TODO
			jsonObject = (JSONObject) jsonp.parse(data);

			String actiontype = jsonObject.get("actiontype").toString();

			String modulename = "";
			if (jsonObject.get("modulename") == null) {
				jsonobjectout.put("status", "0");
				jsonobjectout.put("message", "Please Enter Module Name");
				return jsonobjectout.toJSONString();
			} else {
				modulename = jsonObject.get("modulename").toString().trim();
				if (modulename.length() < 2) {
					jsonobjectout.put("status", "0");
					jsonobjectout.put("message", "Module Name must be of atleast 2 letters.");
					return jsonobjectout.toJSONString();
				} else {
					if (!modulename.matches("^[A-Za-z0-9 _]*[A-Za-z0-9][A-Za-z0-9 _]*$")) {
						jsonobjectout.put("status", "0");
						jsonobjectout.put("message", "Module Name contains Letter and Digits only");
						return jsonobjectout.toJSONString();
					}
				}
			}

			boolean Checkmodulenameexist = false;
			List moduleexistcheck = moduleMasterRepository.CheckModuleNameexist(modulename);
			if (actiontype.equalsIgnoreCase("add")) {
				if (moduleexistcheck.isEmpty()) {
					Checkmodulenameexist = true;
				}
			} else {
				if (moduleexistcheck.isEmpty() || moduleexistcheck.size() == 1) {
					Checkmodulenameexist = true;
				}
			}
			if (Checkmodulenameexist) {

				TB_LDAP_MODULE_MASTER module = new TB_LDAP_MODULE_MASTER();

				module.setModule_name(modulename);

				if (actiontype.equalsIgnoreCase("add")) {

					moduleMasterRepository.save(module);
					jsonobjectout.put("message", "Data Saved Successfully");
					jsonobjectout.put("status", "1");

					returnstring = jsonobjectout.toJSONString();
				} else {

					TB_LDAP_MODULE_MASTER moduleupdate = moduleMasterRepository
							.getById(Integer.parseInt(jsonObject.get("moduleid").toString()));
					if (moduleupdate != null) {
						moduleupdate.setModule_name(modulename);
						moduleMasterRepository.save(moduleupdate);
						jsonobjectout.put("message", "Data updated Successfully");
						jsonobjectout.put("status", "1");

						returnstring = jsonobjectout.toJSONString();
					} else {
						jsonobjectout.put("status", "0");
						jsonobjectout.put("message", "Module ID Not Found");
						returnstring = jsonobjectout.toJSONString();
					}

				}

			} else {
				jsonobjectout.put("status", "0");
				jsonobjectout.put("message", "Module Name already exist");
				returnstring = jsonobjectout.toJSONString();
			}

		} catch (Exception e) {
			e.printStackTrace();
			jsonobjectout.put("status", "0");
			jsonobjectout.put("message", "Failure");
			returnstring = jsonobjectout.toJSONString();
		}
		System.out.println("Output-->" + returnstring);

		return returnstring;
	}
	
	@ResponseBody
	@RequestMapping(value = "/admin/SaveModuleMasterData1", method = RequestMethod.POST, produces = {
			"application/json" })
	public String SaveModuleMasterData1(@RequestBody String data, HttpServletRequest request) {

		JSONObject jsonObject = new JSONObject();
		JSONArray jsonArray1 = new JSONArray();
		JSONParser jsonp = new JSONParser();
		JSONObject jsonobjectout = new JSONObject();
		String returnstring = "";
		try {
			// Add Server Side Validation TODO
			jsonObject = (JSONObject) jsonp.parse(data);

			String actiontype = jsonObject.get("actiontype").toString();

			String modulename = "";
			if (jsonObject.get("modulename") == null) {
				jsonobjectout.put("status", "0");
				jsonobjectout.put("message", "Please Enter Module Name");
				return jsonobjectout.toJSONString();
			} else {
				modulename = jsonObject.get("modulename").toString().trim();
				if (modulename.length() < 2) {
					jsonobjectout.put("status", "0");
					jsonobjectout.put("message", "Module Name must be of atleast 2 letters.");
					return jsonobjectout.toJSONString();
				} else {
					if (!modulename.matches("^[A-Za-z0-9 _]*[A-Za-z0-9][A-Za-z0-9 _]*$")) {
						jsonobjectout.put("status", "0");
						jsonobjectout.put("message", "Module Name contains Letter and Digits only");
						return jsonobjectout.toJSONString();
					}
				}
			}

			boolean Checkmodulenameexist = false;
			List moduleexistcheck = moduleMasterRepository.CheckModuleNameexist(modulename);
			if (actiontype.equalsIgnoreCase("add")) {
				if (moduleexistcheck.isEmpty()) {
					Checkmodulenameexist = true;
				}
			} else {
				if (moduleexistcheck.isEmpty() || moduleexistcheck.size() == 1) {
					Checkmodulenameexist = true;
				}
			}
			if (Checkmodulenameexist) {

				TB_LDAP_MODULE_MASTER module = new TB_LDAP_MODULE_MASTER();

				module.setModule_name(modulename);

				if (actiontype.equalsIgnoreCase("add")) {

					moduleMasterRepository.save(module);
					jsonobjectout.put("message", "Data Saved Successfully");
					jsonobjectout.put("status", "1");

					returnstring = jsonobjectout.toJSONString();
				} else {

					TB_LDAP_MODULE_MASTER moduleupdate = moduleMasterRepository
							.getById(Integer.parseInt(jsonObject.get("moduleid").toString()));
					if (moduleupdate != null) {
						moduleupdate.setModule_name(modulename);
						moduleMasterRepository.save(moduleupdate);
						jsonobjectout.put("message", "Data updated Successfully");
						jsonobjectout.put("status", "1");

						returnstring = jsonobjectout.toJSONString();
					} else {
						jsonobjectout.put("status", "0");
						jsonobjectout.put("message", "Module ID Not Found");
						returnstring = jsonobjectout.toJSONString();
					}

				}

			} else {
				jsonobjectout.put("status", "0");
				jsonobjectout.put("message", "Module Name already exist");
				returnstring = jsonobjectout.toJSONString();
			}

		} catch (Exception e) {
			e.printStackTrace();
			jsonobjectout.put("status", "0");
			jsonobjectout.put("message", "Failure");
			returnstring = jsonobjectout.toJSONString();
		}
		System.out.println("Output-->" + returnstring);

		return returnstring;
	}

	@ResponseBody
	@RequestMapping(value = "/admin/DeleteModuleData", method = RequestMethod.POST, produces = { "application/json" })
	public String DeleteModuleData(@RequestBody String data, HttpServletRequest request) {

		JSONObject jsonObject = new JSONObject();
		JSONArray jsonArray1 = new JSONArray();
		JSONParser jsonp = new JSONParser();
		JSONObject jsonobjectout = new JSONObject();
		String returnstring = "";
		try {
			// Add Server Side Validation TODO
			jsonObject = (JSONObject) jsonp.parse(data);
			if (jsonObject.get("moduleid") != null) {

				int moduleid = Integer.parseInt(AES.decrypt(jsonObject.get("moduleid").toString()));
				TB_LDAP_MODULE_MASTER master = moduleMasterRepository.getById(moduleid);
				if (master != null) {
					moduleMasterRepository.delete(master);
					jsonobjectout.put("status", "1");
					jsonobjectout.put("message", "Data Deleted Successfully");
					returnstring = jsonobjectout.toJSONString();
				} else {
					jsonobjectout.put("status", "0");
					jsonobjectout.put("message", "No Data Found");
					returnstring = jsonobjectout.toJSONString();
				}

			} else {
				jsonobjectout.put("status", "0");
				jsonobjectout.put("message", "No Data Found");
				returnstring = jsonobjectout.toJSONString();
			}

		} catch (Exception e) {
			e.printStackTrace();
			jsonobjectout.put("status", "0");
			jsonobjectout.put("message", "Failure");
			returnstring = jsonobjectout.toJSONString();
		}
//		System.out.println("Output-->" + returnstring);

		return returnstring;
	}

	@ResponseBody
	@RequestMapping(value = "/admin/GetModuleDataForUpdate", method = RequestMethod.POST, produces = {
			"application/json" })
	public String GetModuleDataForUpdate(@RequestBody String data, HttpServletRequest request) {

		JSONObject jsonObject = new JSONObject();
		JSONArray jsonArray1 = new JSONArray();
		JSONParser jsonp = new JSONParser();
		JSONObject jsonobjectout = new JSONObject();
		String returnstring = "";
		try {
			// Add Server Side Validation TODO
			jsonObject = (JSONObject) jsonp.parse(data);
			if (jsonObject.get("moduleid") != null) {

				int moduleid = Integer.parseInt(AES.decrypt(jsonObject.get("moduleid").toString()));

				TB_LDAP_MODULE_MASTER tb_LDAP_MODULE_MASTER = moduleMasterRepository.getById(moduleid);
				if (tb_LDAP_MODULE_MASTER != null) {
					jsonobjectout.put("status", "1");
					jsonobjectout.put("modulename", tb_LDAP_MODULE_MASTER.getModule_name());

					jsonobjectout.put("moduleid", tb_LDAP_MODULE_MASTER.getId());
					returnstring = jsonobjectout.toJSONString();
				} else {
					jsonobjectout.put("status", "0");
					jsonobjectout.put("message", "No Data Found");
					returnstring = jsonobjectout.toJSONString();
				}

			} else {
				jsonobjectout.put("status", "0");
				jsonobjectout.put("message", "No Data Found");
				returnstring = jsonobjectout.toJSONString();
			}

		} catch (Exception e) {
			e.printStackTrace();
			jsonobjectout.put("status", "0");
			jsonobjectout.put("message", "Failure");
			returnstring = jsonobjectout.toJSONString();
		}
		System.out.println("Output-->" + returnstring);

		return returnstring;
	}

}
