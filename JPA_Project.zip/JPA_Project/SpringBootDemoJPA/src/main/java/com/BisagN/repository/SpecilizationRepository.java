package com.BisagN.repository;

import java.util.List;

import javax.persistence.Tuple;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.BisagN.models.Specializationmst;

@Repository
public interface SpecilizationRepository extends JpaRepository<Specializationmst, Integer> {

	@Query(value = "From Specializationmst where status = '1'", countQuery = "select count(*) From Specializationmst where status = '1'")
	Page<Specializationmst> LoadSpecializationData(Pageable pageable);
}
