/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.BisagN.models;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author rdp
 */
@Entity
@Table(name = "institutemst")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Institutemst.findAll", query = "SELECT i FROM Institutemst i"),
    @NamedQuery(name = "Institutemst.findByInid", query = "SELECT i FROM Institutemst i WHERE i.inid = :inid"),
    @NamedQuery(name = "Institutemst.findByInscode", query = "SELECT i FROM Institutemst i WHERE i.inscode = :inscode"),
    @NamedQuery(name = "Institutemst.findByInsname", query = "SELECT i FROM Institutemst i WHERE i.insname = :insname"),
    @NamedQuery(name = "Institutemst.findByInsemail", query = "SELECT i FROM Institutemst i WHERE i.insemail = :insemail"),
    @NamedQuery(name = "Institutemst.findByInsmobile", query = "SELECT i FROM Institutemst i WHERE i.insmobile = :insmobile"),
    @NamedQuery(name = "Institutemst.findByAddress", query = "SELECT i FROM Institutemst i WHERE i.address = :address"),
    @NamedQuery(name = "Institutemst.findByStatus", query = "SELECT i FROM Institutemst i WHERE i.status = :status"),
    @NamedQuery(name = "Institutemst.findByCreaetby", query = "SELECT i FROM Institutemst i WHERE i.creaetby = :creaetby"),
    @NamedQuery(name = "Institutemst.findByCreatedate", query = "SELECT i FROM Institutemst i WHERE i.createdate = :createdate"),
    @NamedQuery(name = "Institutemst.findByModifyby", query = "SELECT i FROM Institutemst i WHERE i.modifyby = :modifyby"),
    @NamedQuery(name = "Institutemst.findByModifydate", query = "SELECT i FROM Institutemst i WHERE i.modifydate = :modifydate"),
    @NamedQuery(name = "Institutemst.findByYear", query = "SELECT i FROM Institutemst i WHERE i.year = :year")})
public class Institutemst implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "inid")
    private Long inid;
    @Basic(optional = false)
    @Column(name = "inscode")
    private String inscode;
    @Basic(optional = false)
    @Column(name = "insname")
    private String insname;
    @Basic(optional = false)
    @Column(name = "insemail")
    private String insemail;
    @Basic(optional = false)
    @Column(name = "insmobile")
    private String insmobile;
    @Basic(optional = false)
    @Column(name = "address")
    private String address;
    @Basic(optional = false)
    @Column(name = "status")
    private Character status;
    @Basic(optional = false)
    @Column(name = "creaetby")
    private int creaetby;
    @Basic(optional = false)
    @Column(name = "createdate")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdate;
    @Column(name = "modifyby")
    private Integer modifyby;
    @Column(name = "modifydate")
    @Temporal(TemporalType.TIMESTAMP)
    private Date modifydate;
    @Column(name = "year")
    private String year;
    @JoinColumn(name = "cid", referencedColumnName = "cid")
    @ManyToOne
    private Countrymst cid;
    @JoinColumn(name = "did", referencedColumnName = "did")
    @ManyToOne
    private Districtmst did;
    @JoinColumn(name = "sid", referencedColumnName = "sid")
    @ManyToOne
    private Statemaster sid;

    public Institutemst() {
    }

    public Institutemst(Long inid) {
        this.inid = inid;
    }

    public Institutemst(Long inid, String inscode, String insname, String insemail, String insmobile, String address, Character status, int creaetby, Date createdate) {
        this.inid = inid;
        this.inscode = inscode;
        this.insname = insname;
        this.insemail = insemail;
        this.insmobile = insmobile;
        this.address = address;
        this.status = status;
        this.creaetby = creaetby;
        this.createdate = createdate;
    }

    public Long getInid() {
        return inid;
    }

    public void setInid(Long inid) {
        this.inid = inid;
    }

    public String getInscode() {
        return inscode;
    }

    public void setInscode(String inscode) {
        this.inscode = inscode;
    }

    public String getInsname() {
        return insname;
    }

    public void setInsname(String insname) {
        this.insname = insname;
    }

    public String getInsemail() {
        return insemail;
    }

    public void setInsemail(String insemail) {
        this.insemail = insemail;
    }

    public String getInsmobile() {
        return insmobile;
    }

    public void setInsmobile(String insmobile) {
        this.insmobile = insmobile;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public Character getStatus() {
        return status;
    }

    public void setStatus(Character status) {
        this.status = status;
    }

    public int getCreaetby() {
        return creaetby;
    }

    public void setCreaetby(int creaetby) {
        this.creaetby = creaetby;
    }

    public Date getCreatedate() {
        return createdate;
    }

    public void setCreatedate(Date createdate) {
        this.createdate = createdate;
    }

    public Integer getModifyby() {
        return modifyby;
    }

    public void setModifyby(Integer modifyby) {
        this.modifyby = modifyby;
    }

    public Date getModifydate() {
        return modifydate;
    }

    public void setModifydate(Date modifydate) {
        this.modifydate = modifydate;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public Countrymst getCid() {
        return cid;
    }

    public void setCid(Countrymst cid) {
        this.cid = cid;
    }

    public Districtmst getDid() {
        return did;
    }

    public void setDid(Districtmst did) {
        this.did = did;
    }

    public Statemaster getSid() {
        return sid;
    }

    public void setSid(Statemaster sid) {
        this.sid = sid;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (inid != null ? inid.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Institutemst)) {
            return false;
        }
        Institutemst other = (Institutemst) object;
        if ((this.inid == null && other.inid != null) || (this.inid != null && !this.inid.equals(other.inid))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.bisag.entity.Institutemst[ inid=" + inid + " ]";
    }
    
}
