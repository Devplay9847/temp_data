/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.BisagN.models;

import java.io.Serializable;
import java.util.Collection;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author rdp
 */
@Entity
@Table(name = "statemaster")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Statemaster.findAll", query = "SELECT s FROM Statemaster s"),
    @NamedQuery(name = "Statemaster.findBySid", query = "SELECT s FROM Statemaster s WHERE s.sid = :sid"),
    @NamedQuery(name = "Statemaster.findByStatename", query = "SELECT s FROM Statemaster s WHERE s.statename = :statename"),
    @NamedQuery(name = "Statemaster.findByCreatetby", query = "SELECT s FROM Statemaster s WHERE s.createtby = :createtby"),
    @NamedQuery(name = "Statemaster.findByCreatedate", query = "SELECT s FROM Statemaster s WHERE s.createdate = :createdate"),
    @NamedQuery(name = "Statemaster.findByModifyby", query = "SELECT s FROM Statemaster s WHERE s.modifyby = :modifyby"),
    @NamedQuery(name = "Statemaster.findByModifydate", query = "SELECT s FROM Statemaster s WHERE s.modifydate = :modifydate"),
    @NamedQuery(name = "Statemaster.findByStatus", query = "SELECT s FROM Statemaster s WHERE s.status = :status")})
public class Statemaster implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "sid")
    private Integer sid;
    @Basic(optional = false)
    @Column(name = "statename")
    private String statename;
    @Basic(optional = false)
    @Column(name = "createtby")
    private int createtby;
    @Basic(optional = false)
    @Column(name = "createdate")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdate;
    @Column(name = "modifyby")
    private Integer modifyby;
    @Column(name = "modifydate")
    @Temporal(TemporalType.TIMESTAMP)
    private Date modifydate;
    @Basic(optional = false)
    @Column(name = "status")
    private Character status;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "sid")
    private Collection<Districtmst> districtmstCollection;
    @JoinColumn(name = "cid", referencedColumnName = "cid")
    @ManyToOne(optional = false)
    private Countrymst cid;

    public Statemaster() {
    }

    public Statemaster(Integer sid) {
        this.sid = sid;
    }

    public Statemaster(Integer sid, String statename, int createtby, Date createdate, Character status) {
        this.sid = sid;
        this.statename = statename;
        this.createtby = createtby;
        this.createdate = createdate;
        this.status = status;
    }

    public Integer getSid() {
        return sid;
    }

    public void setSid(Integer sid) {
        this.sid = sid;
    }

    public String getStatename() {
        return statename;
    }

    public void setStatename(String statename) {
        this.statename = statename;
    }

    public int getCreatetby() {
        return createtby;
    }

    public void setCreatetby(int createtby) {
        this.createtby = createtby;
    }

    public Date getCreatedate() {
        return createdate;
    }

    public void setCreatedate(Date createdate) {
        this.createdate = createdate;
    }

    public Integer getModifyby() {
        return modifyby;
    }

    public void setModifyby(Integer modifyby) {
        this.modifyby = modifyby;
    }

    public Date getModifydate() {
        return modifydate;
    }

    public void setModifydate(Date modifydate) {
        this.modifydate = modifydate;
    }

    public Character getStatus() {
        return status;
    }

    public void setStatus(Character status) {
        this.status = status;
    }

    @XmlTransient
    public Collection<Districtmst> getDistrictmstCollection() {
        return districtmstCollection;
    }

    public void setDistrictmstCollection(Collection<Districtmst> districtmstCollection) {
        this.districtmstCollection = districtmstCollection;
    }

    public Countrymst getCid() {
        return cid;
    }

    public void setCid(Countrymst cid) {
        this.cid = cid;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (sid != null ? sid.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Statemaster)) {
            return false;
        }
        Statemaster other = (Statemaster) object;
        if ((this.sid == null && other.sid != null) || (this.sid != null && !this.sid.equals(other.sid))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.mycompany.mavenproject1.Statemaster[ sid=" + sid + " ]";
    }
    
}
