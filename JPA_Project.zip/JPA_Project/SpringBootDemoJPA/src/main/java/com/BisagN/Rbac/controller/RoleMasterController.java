package com.BisagN.Rbac.controller;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.BisagN.controller.AES;

import com.BisagN.models.Role;

import com.BisagN.models.TB_LDAP_ROLE_TYPE;
import com.BisagN.repository.RoleRepository;
import com.BisagN.repository.RoleTypeRepository;

@Controller
public class RoleMasterController {

	@Autowired
	RoleTypeRepository roleTypeRepository;

	@Autowired
	RoleRepository roleRepository;

	@RequestMapping(value = "/admin/RoleMaster", method = RequestMethod.GET)
	public ModelAndView RoleMaster() {
		ModelAndView model = new ModelAndView();
		model.setViewName("RoleMaster");
		return model;
	}

	@ResponseBody
	@RequestMapping(value = "/admin/GetRoleType", method = RequestMethod.POST, produces = { "application/json" })
	public String GetRoleType(HttpServletRequest request) {
		JSONArray jSONArray = new JSONArray();
		JSONObject object = new JSONObject();

		JSONObject object1 = new JSONObject();

		try {
			System.out.println("dsg");
			List<TB_LDAP_ROLE_TYPE> list1 = roleTypeRepository.GetRoleType();

			System.out.println("list1.size()" + list1.size());
			if (!list1.isEmpty()) {

				for (TB_LDAP_ROLE_TYPE tb_LDAP_ROLE_TYPE : list1) {
					object = new JSONObject();

					object.put("id", tb_LDAP_ROLE_TYPE.getId());
					object.put("name", tb_LDAP_ROLE_TYPE.getRole_type());
					jSONArray.add(object);
				}
				object1.put("roletypelist", jSONArray);
			} else {
				jSONArray = new JSONArray();
				object1.put("roletypelist", jSONArray);
			}

			object1.put("Status", "1");
			object1.put("Message", "Success");

		} catch (Exception e) {
			e.printStackTrace();
			object1 = new JSONObject();
			object1.put("Status", "0");
			object1.put("Message", "Something went wrong");
		}
		System.out.println("object1.toJSONString()" + object1.toJSONString());
		return object1.toJSONString();
	}

	@ResponseBody
	@RequestMapping(value = "/admin/LoadRoleMasterData", method = RequestMethod.POST, produces = { "application/json" })
	public String LoadRoleMasterData(HttpServletRequest request) {

		JSONObject jsonObject = new JSONObject();
		JSONArray jsonArray1 = new JSONArray();
		JSONParser jsonp = new JSONParser();
		JSONObject jsonobjectout = new JSONObject();
		String returnstring = "";
		try {
			// Add Server Side Validation TODO
			List<Role> rolelist = roleRepository.LoadRoleData();
			int counter = 1;
			for (Role role : rolelist) {

				JSONObject jsonObject2 = new JSONObject();
				jsonObject2.put("srno", "<span class='avtar avatar-blue'>" + counter + "</span>");
				jsonObject2.put("rolename", role.getRole());
				jsonObject2.put("roleurl", role.getRole_url());
				jsonObject2.put("roletype", role.getRole_type());
				if (role.getAccess_lvl() != null && !role.getAccess_lvl().equalsIgnoreCase("")) {
					jsonObject2.put("accesslevel", role.getAccess_lvl());
				} else {
					jsonObject2.put("accesslevel", "-");
				}
				if (role.getSub_access_lvl() != null && !role.getSub_access_lvl().equalsIgnoreCase("")) {
					jsonObject2.put("subaccesslevel", role.getSub_access_lvl());
				} else {
					jsonObject2.put("subaccesslevel", "-");
				}
				if (role.getStaff_lvl() != null && !role.getStaff_lvl().equalsIgnoreCase("")) {
					jsonObject2.put("stafflevel", role.getStaff_lvl());
				} else {
					jsonObject2.put("stafflevel", "-");
				}
				jsonObject2.put("action", "<a href=\"#\" onclick=\"GetRoleData('" + AES.encrypt(role.getRoleId() + "")
						+ "')\"><i class=\"fa fa-pencil\" aria-hidden=\"true\"></i></a> &nbsp;&nbsp; <a href=\"#\" onclick=\"DeleteRoleData('"
						+ AES.encrypt(role.getRoleId() + "")
						+ "')\"><i class=\"fa fa-trash\" aria-hidden=\"true\"></i></a>");
				jsonArray1.add(jsonObject2);
				counter++;
			}
			jsonobjectout.put("status", "1");
			jsonobjectout.put("data", jsonArray1);
			jsonobjectout.put("message", "Data Saved Successfully");
			returnstring = jsonobjectout.toJSONString();
		} catch (Exception e) {
			e.printStackTrace();
			jsonobjectout.put("status", "0");
			jsonobjectout.put("message", "Failure");
			returnstring = jsonobjectout.toJSONString();
		}
//		System.out.println("Output-->" + returnstring);

		return returnstring;
	}

	@ResponseBody
	@RequestMapping(value = "/admin/SaveRoleMasterData", method = RequestMethod.POST, produces = { "application/json" })
	public String SaveRoleMasterData(@RequestBody String data, HttpServletRequest request) {

		JSONObject jsonObject = new JSONObject();
		JSONArray jsonArray1 = new JSONArray();
		JSONParser jsonp = new JSONParser();
		JSONObject jsonobjectout = new JSONObject();
		String returnstring = "";
		try {
			// Add Server Side Validation TODO
			jsonObject = (JSONObject) jsonp.parse(data);
		
			String actiontype = jsonObject.get("actiontype").toString();

			String rolename = "";
			if (jsonObject.get("rolename") == null) {
				jsonobjectout.put("status", "0");
				jsonobjectout.put("message", "Please Enter Role Name");
				return jsonobjectout.toJSONString();
			} else {
				rolename = jsonObject.get("rolename").toString().trim();
				if (rolename.length() < 2) {
					jsonobjectout.put("status", "0");
					jsonobjectout.put("message", "Role Name must be of atleast 2 letters.");
					return jsonobjectout.toJSONString();
				} else {
					if (!rolename.matches("^[A-Za-z0-9 _]*[A-Za-z0-9][A-Za-z0-9 _]*$")) {
						jsonobjectout.put("status", "0");
						jsonobjectout.put("message", "Role Name contains Letter and Digits only");
						return jsonobjectout.toJSONString();
					}
				}
			}
			String roleurl = "";
			if (jsonObject.get("roleurl") == null) {
				jsonobjectout.put("status", "0");
				jsonobjectout.put("message", "Please Enter Role URL");
				return jsonobjectout.toJSONString();
			} else {
				roleurl = jsonObject.get("roleurl").toString().trim();
				if (roleurl.length() < 4) {
					jsonobjectout.put("status", "0");
					jsonobjectout.put("message", "Role URL must be of atleast 4 letters.");
					return jsonobjectout.toJSONString();
				}
			}

			String roletype = "";
			if (jsonObject.get("roletype") == null) {
				jsonobjectout.put("status", "0");
				jsonobjectout.put("message", "Please Select Role Type");
				return jsonobjectout.toJSONString();
			} else {
				roletype = jsonObject.get("roletype").toString().trim();
				if (roletype.equalsIgnoreCase("-1")) {
					jsonobjectout.put("status", "0");
					jsonobjectout.put("message", "Please Select Role type");
					return jsonobjectout.toJSONString();
				}
			}

			String accesslevel = "";
			if (jsonObject.get("accesslevel") == null) {
				jsonobjectout.put("status", "0");
				jsonobjectout.put("message", "Please Select Access Level");
				return jsonobjectout.toJSONString();
			} else {
				accesslevel = jsonObject.get("accesslevel").toString().trim();
				if (accesslevel.equalsIgnoreCase("-1")) {
					jsonobjectout.put("status", "0");
					jsonobjectout.put("message", "Please Select Access Level");
					return jsonobjectout.toJSONString();
				}
			}
			boolean Checkrolenameexist = false;
			List roleexistcheck = roleRepository.CheckRoleNameexist(rolename);
			if (actiontype.equalsIgnoreCase("add")) {
				if (roleexistcheck.isEmpty()) {
					Checkrolenameexist = true;
				}
			} else {
				if (roleexistcheck.isEmpty() || roleexistcheck.size() == 1) {
					Checkrolenameexist = true;
				}
			}
			if (Checkrolenameexist) {

				Role role = new Role();

				role.setRole(rolename);
				role.setRole_type(roletype);
				role.setAccess_lvl(accesslevel);
				role.setRole_url(roleurl);

				if (actiontype.equalsIgnoreCase("add")) {

					roleRepository.save(role);
					jsonobjectout.put("message", "Data Saved Successfully");
					jsonobjectout.put("status", "1");

					returnstring = jsonobjectout.toJSONString();
				} else {

					Role roleupdate = roleRepository.getById(Integer.parseInt(jsonObject.get("roleid").toString()));
					if (roleupdate != null) {
						roleupdate.setRole(rolename);
						roleupdate.setRole_type(roletype);
						roleupdate.setAccess_lvl(accesslevel);
						roleupdate.setRole_url(roleurl);
						roleRepository.save(roleupdate);
						jsonobjectout.put("message", "Data updated Successfully");
						jsonobjectout.put("status", "1");

						returnstring = jsonobjectout.toJSONString();
					} else {
						jsonobjectout.put("status", "0");
						jsonobjectout.put("message", "Role ID Not Found");
						returnstring = jsonobjectout.toJSONString();
					}

				}

			} else {
				jsonobjectout.put("status", "0");
				jsonobjectout.put("message", "Role Name already exist");
				returnstring = jsonobjectout.toJSONString();
			}

		} catch (Exception e) {
			e.printStackTrace();
			jsonobjectout.put("status", "0");
			jsonobjectout.put("message", "Failure");
			returnstring = jsonobjectout.toJSONString();
		}
		System.out.println("Output-->" + returnstring);

		return returnstring;
	}

	@ResponseBody
	@RequestMapping(value = "/admin/DeleteRoleData", method = RequestMethod.POST, produces = { "application/json" })
	public String DeleteRoleData(@RequestBody String data, HttpServletRequest request) {

		JSONObject jsonObject = new JSONObject();
		JSONArray jsonArray1 = new JSONArray();
		JSONParser jsonp = new JSONParser();
		JSONObject jsonobjectout = new JSONObject();
		String returnstring = "";
		try {
			// Add Server Side Validation TODO
			jsonObject = (JSONObject) jsonp.parse(data);
			if (jsonObject.get("roleid") != null) {

				int roleid = Integer.parseInt(AES.decrypt(jsonObject.get("roleid").toString()));
				Role role = roleRepository.getById(roleid);
				if (role != null) {
					roleRepository.delete(role);
					jsonobjectout.put("status", "1");
					jsonobjectout.put("message", "Data Deleted Successfully");
					returnstring = jsonobjectout.toJSONString();
				} else {
					jsonobjectout.put("status", "0");
					jsonobjectout.put("message", "No Data Found");
					returnstring = jsonobjectout.toJSONString();
				}

			} else {
				jsonobjectout.put("status", "0");
				jsonobjectout.put("message", "No Data Found");
				returnstring = jsonobjectout.toJSONString();
			}

		} catch (Exception e) {
			e.printStackTrace();
			jsonobjectout.put("status", "0");
			jsonobjectout.put("message", "Failure");
			returnstring = jsonobjectout.toJSONString();
		}
//		System.out.println("Output-->" + returnstring);

		return returnstring;
	}

	@ResponseBody
	@RequestMapping(value = "/admin/GetRoleDataForUpdate", method = RequestMethod.POST, produces = {
			"application/json" })
	public String GetRoleDataForUpdate(@RequestBody String data, HttpServletRequest request) {

		JSONObject jsonObject = new JSONObject();
		JSONArray jsonArray1 = new JSONArray();
		JSONParser jsonp = new JSONParser();
		JSONObject jsonobjectout = new JSONObject();
		String returnstring = "";
		try {
			// Add Server Side Validation TODO
			jsonObject = (JSONObject) jsonp.parse(data);
			if (jsonObject.get("roleid") != null) {

				int roleid = Integer.parseInt(AES.decrypt(jsonObject.get("roleid").toString()));

				Role role = roleRepository.getById(roleid);
				if (role != null) {
					jsonobjectout.put("status", "1");
					jsonobjectout.put("rolename", role.getRole());
					jsonobjectout.put("roleurl", role.getRole_url());
					jsonobjectout.put("roletype", role.getRole_type());
					if (role.getAccess_lvl() != null && !role.getAccess_lvl().equalsIgnoreCase("")) {
						jsonobjectout.put("accesslevel", role.getAccess_lvl());
					} else {
						jsonobjectout.put("accesslevel", "");
					}
					if (role.getSub_access_lvl() != null && !role.getSub_access_lvl().equalsIgnoreCase("")) {
						jsonobjectout.put("subaccesslevel", role.getSub_access_lvl());
					} else {
						jsonobjectout.put("subaccesslevel", "");
					}
					if (role.getStaff_lvl() != null && !role.getStaff_lvl().equalsIgnoreCase("")) {
						jsonobjectout.put("stafflevel", role.getStaff_lvl());
					} else {
						jsonobjectout.put("stafflevel", "");
					}
					jsonobjectout.put("roleid", role.getRoleId());
					returnstring = jsonobjectout.toJSONString();
				} else {
					jsonobjectout.put("status", "0");
					jsonobjectout.put("message", "No Data Found");
					returnstring = jsonobjectout.toJSONString();
				}

			} else {
				jsonobjectout.put("status", "0");
				jsonobjectout.put("message", "No Data Found");
				returnstring = jsonobjectout.toJSONString();
			}

		} catch (Exception e) {
			e.printStackTrace();
			jsonobjectout.put("status", "0");
			jsonobjectout.put("message", "Failure");
			returnstring = jsonobjectout.toJSONString();
		}
		System.out.println("Output-->" + returnstring);

		return returnstring;
	}

}
