package com.BisagN.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.BisagN.models.TB_LDAP_MODULE_MASTER;
import com.BisagN.models.TB_LDAP_SCREEN_MASTER;
import com.BisagN.models.TB_LDAP_SUBMODULE_MASTER;
import com.BisagN.models.UserLogin;

@Repository
public interface UserLoginRepository extends JpaRepository<UserLogin, Integer> {

	@Query("FROM UserLogin U where U.userName=?1")
	public UserLogin findUser(String userName);

	@Query("FROM UserLogin U where U.userId=?1")
	public UserLogin findByRoleId(int userId);

	@Query(value = "Select cast(r.role as text) from userroleinformation ur, roleinformation r where ur.role_id = r.role_id and cast(ur.user_id as text) =?1"
			, nativeQuery = true)
	public List<String> getRoleByuserId(String userId);
	
	@Query("from TB_LDAP_MODULE_MASTER b where b.id > 0 and b.id in (select a.module.id from TB_LDAP_ROLEMASTER a where a.roleid=?1 and  a.module.id != 0 ) order by b.id")
	public List<TB_LDAP_MODULE_MASTER> getModulelist(int roleid);
	
	@Query("from TB_LDAP_SUBMODULE_MASTER b where b.module.id =?1 and b.id in (select a.sub_module.id from TB_LDAP_ROLEMASTER a where a.roleid=?2) order by b.id ")
	public List<TB_LDAP_SUBMODULE_MASTER> getSubModulelist(int  moduleid,int roleid);
	
	@Query("from TB_LDAP_SCREEN_MASTER b where b.id in (select a.screen.id from TB_LDAP_ROLEMASTER a where a.roleid=?3 and  a.module.id =?1 and a.sub_module.id =?2) order by b.id")
	public List<TB_LDAP_SCREEN_MASTER> getScreenlist(int  moduleid,int submoduleid,int roleid);
}
