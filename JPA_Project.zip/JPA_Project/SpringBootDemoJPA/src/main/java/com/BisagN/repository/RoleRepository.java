package com.BisagN.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.BisagN.models.Role;
import com.BisagN.models.UserLogin;

@Repository
public interface RoleRepository extends JpaRepository<Role, Integer> {

	@Query("FROM Role U where U.role=?1")
	public Role findRole_url(String role);

	@Query(value = "SELECT t.msg from tb_hd_mercuries t WHERE t.valid_upto >= now()", nativeQuery = true)
	public List<String> getLayoutlist();

	@Query(value = "SELECT nextval('login_visitor_count')", nativeQuery = true)
	public int VisitorCounter();

	@Query("FROM Role U")
	public List<Role> LoadRoleData();

	@Query("FROM Role where role=?1")
	public List CheckRoleNameexist(String rolename);

}
