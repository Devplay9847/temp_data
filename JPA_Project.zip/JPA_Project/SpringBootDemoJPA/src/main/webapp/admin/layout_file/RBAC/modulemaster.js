$(document).ready(function() {
	var table = $('#modulemastertbl').DataTable({
		rowReorder: {
			selector: 'td:nth-child(2)'
		},
		responsive: true,
		"scrollY": "400px",
		"scrollX": true,
		"scrollCollapse": true,
	});


});
$(document).ready(function() {

	$("#modulename").keypress(function(event) {
		var inputValue = event.which;

		// allow letters and whitespaces only.
		if (!(inputValue == 32) && // space
			!(inputValue > 48 && inputValue < 58) && // numeric (0-9)
			!(inputValue > 64 && inputValue < 91) && // upper alpha (A-Z)
			!(inputValue > 96 && inputValue < 123)) {
			event.preventDefault();
		}
	});
	$('#modulemasterdiv').block({ message: 'Please wait....' });
	$.ajax(
		{
			url: '/AFMS/admin/LoadModuleMasterData',
			type: "POST",
			contentType: 'application/json',
			dataType: 'json',

		})
		.done(
			function(data) {

				if (data.status == '1') {


					var length = Object.keys(data.data).length;

					$('#modulemastertbl').dataTable().fnClearTable();
					for (var i = 0; i < length; i++) {
						var statusData = data.data[i];
						$('#modulemastertbl').dataTable().fnAddData([
							statusData.srno,
							statusData.modulename,
							statusData.action


						]);
					}
					$('#modulemasterdiv').unblock();
				} else {
					$('#modulemasterdiv').unblock();
					swal(data.message);
				}

			})
		.fail(function(jqXHR, textStatus) {
			$('#modulemasterdiv').unblock();
			swal(jqXHR.responseText);
		});

});
function SaveModuleMasterData() {
	var modulename = document.getElementById("modulename").value.trim();



	if (modulename == "" || modulename == null || modulename == undefined) {
		swal('Please Enter Module Name');
		return false;
	}
	if (modulename.length < 2) {
		swal('Module Name must be of atleast 2 letters.');
		return false;
	}



	$('#modulemasterdiv').block({ message: 'Please wait....' });
	var jsondata = {
		"modulename": modulename,
		"actiontype": document.getElementById("actiontype").value,
		"moduleid": document.getElementById("moduleid").value
	}

	$
		.ajax(
			{
				url: '/AFMS/admin/SaveModuleMasterData',
				type: "POST",
				data: JSON
					.stringify(jsondata),
				contentType: 'application/json',
				cors: true,
				dataType: 'json',

			})
		.done(
			function(data) {
				$('#modulemasterdiv').unblock();
				if (data.status == '1') {


					swal(data.message)
						.then((value) => {
							window.location.reload();
						});


				} else {
					swal(data.message);




				}
			})
		.fail(function(jqXHR, textStatus) {
			swal(jqXHR.responseText);
			//swal('File upload failed ...');
		});

}

function GetModuleData(moduleid) {

	$('#modulemasterdiv').block({ message: 'Please wait....' });
	var jsondata = {
		"moduleid": moduleid
	}

	$
		.ajax(
			{
				url: '/AFMS/admin/GetModuleDataForUpdate',
				type: "POST",
				data: JSON
					.stringify(jsondata),
				contentType: 'application/json',
				cors: true,
				dataType: 'json',

			})
		.done(
			function(data) {
				$('#modulemasterdiv').unblock();
				if (data.status == '1') {
					document.getElementById("modulename").value = data.modulename;
					document.getElementById("moduleid").value = data.moduleid;

					document.getElementById("actiontype").value = "Edit";
					document.getElementById("docbtn").value = "Update";
				} else {
					swal(data.message);
				}
			})
		.fail(function(jqXHR, textStatus) {
			//swal(jqXHR.responseText);
			swal('File upload failed ...');
		});
}
function DeleteModuleData(moduleid) {
	$('#modulemasterdiv').block({ message: 'Please wait....' });
	var jsondata = {
		"moduleid": moduleid
	}

	$
		.ajax(
			{
				url: '/AFMS/admin/DeleteModuleData',
				type: "POST",
				data: JSON
					.stringify(jsondata),
				contentType: 'application/json',
				cors: true,
				dataType: 'json',

			})
		.done(
			function(data) {
				$('#modulemasterdiv').unblock();
				if (data.status == '1') {
					swal(data.message)
						.then((value) => {
							window.location.reload();
						});
				} else {
					swal(data.message);
				}
			})
		.fail(function(jqXHR, textStatus) {
			$('#modulemasterdiv').unblock();
			swal(jqXHR.responseText);

		});

}

function ResetInput() {
	window.location.reload();
}
