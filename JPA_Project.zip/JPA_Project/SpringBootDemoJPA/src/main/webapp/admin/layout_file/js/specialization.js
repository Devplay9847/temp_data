$(document).ready(function() {

	//
	//	var table1 = $('#specializationtbl').DataTable({
	//		rowReorder: {
	//			selector: 'td:nth-child(2)'
	//		},
	//		responsive: true,
	//		"scrollY": "400px",
	//		"scrollX": true,
	//		"scrollCollapse": true,
	//	});
	$("#coursename").keypress(function(event) {
		var inputValue = event.which;
		if (!(inputValue >= 65 && inputValue <= 90) && !(inputValue >= 97 && inputValue <= 122) && (inputValue != 32 && inputValue != 0 && inputValue != 8)) {
			event.preventDefault();
		}
	});

	mockjax1('specializationtbl');
	dt = dataTable('specializationtbl');
});


function dataTable(tableName) {
	var table = $('#' + tableName).DataTable({
		"order": [[0, "asc"]],
		//		"lengthMenu": [[10, 25, 50, 100, 200, -1], [10, 25, 50, 100, 200, "All"]],
		"lengthMenu": [[10, 25, 50, 100, -1], [10, 25, 50, 100, "All"]],
		"scrollY": "400px",
		"scrollX": true,
		"scrollCollapse": true,
		"sPaginationType": "full_numbers",
		"bLengthChange": true,
		'language': {
			'loadingRecords': '&nbsp;',
			'processing': '<div class="spinner"></div>'
		},
		ajax: '/test1',
		'processing': true,
		"serverSide": true
	});
	return table;
}
function mockjax1(tableName) {

	$.mockjax({
		url: '/test1',
		responseTime: 1000,
		response: function(settings) {
			$.ajaxSetup({
				async: false
			});
			data(tableName);
			this.responseText = {
				draw: settings.data.draw,
				data: jsondata,
				recordsTotal: jsondata.length,
				recordsFiltered: FilteredRecords
			};


		}
	});
}

function data(tableName) {


	var table = $('#' + tableName).DataTable();
	var info = table.page.info();
	var currentPage = info.page;
	var pageLength = info.length;
	var startPage = info.start;
	var endPage = info.end;
	var Search = table.search();
	var order = table.order();
	var orderColunm = '3';
	var orderColunm = order[0][0] + 1;
	//alert(orderColunm);
	//var orderColunm = "d.id"

	var orderType = order[0][1];

	jsondata = [];

	$('#specializationdiv').block({ message: 'Please wait....' });
	$.ajax(
		{
			url: '/AFMS/admin/LoadSpecializationData?pageno=' + currentPage + '&&length=' + pageLength + "&&search=" + Search,
			type: "POST",
			contentType: 'application/json',
			dataType: 'json',

		})
		.done(
			function(data) {

				if (data.status == '1') {
					var length = Object.keys(data.data).length;
					for (var i = 0; i < length; i++) {
						var statusData = data.data[i];
						jsondata.push([
							statusData.srno,
							statusData.name,
							statusData.year,
							statusData.action

						]);
						FilteredRecords = data.TotalCount;
					}
					$('#specializationdiv').unblock();
				} else {
					$('#specializationdiv').unblock();
					swal(data.message);
				}
			})
		.fail(function(jqXHR, textStatus) {
			$('#specializationdiv').unblock();
			swal(jqXHR.responseText);
		});
}
$(document).ready(function() {
	var curyear = new Date().getFullYear();
	var nextyear = new Date().getFullYear() + 1;
	document.getElementById("year").value = curyear + "-" + nextyear;
});
function ResetInput() {
	window.location.reload();
}
function SaveSpecializationData() {
	var coursename = document.getElementById("coursename").value;
	var year = document.getElementById("year").value;

	if (coursename == "" || coursename == null || coursename == undefined) {
		swal('Please Enter Specialization Name');
		return false;
	}
	if (coursename.length < 2) {
		swal('Specialization Name must be of atleast 2 Letters.');
		return false;
	}
	var regex = /^[a-zA-Z ]*$/;//For Alphabet and Space
	if (!regex.test(coursename)) {
		swal('Specialization Name must be of Alphabet');
		return false;
	}
	if (year == "" || year == null || year == undefined) {
		swal('Please Enter Year');
		return false;
	}
	if (year.length < 9) {
		swal('Year must be of atleast 9 letters.');
		return false;
	}


	$('#specializationdiv').block({ message: 'Please wait....' });
	if (document.getElementById("actiontype").value == "add") {
		var jsondata = {

			"specializationname": coursename,
			"year": year
		}
	} else {
		var jsondata = {
			"sid": document.getElementById("sid").value,
			"specializationname": coursename,
			"year": year
		}
	}

	$
		.ajax(
			{
				url: '/AFMS/admin/SaveSpecializationData',
				type: "POST",
				data: JSON
					.stringify(jsondata),
				contentType: 'application/json',
				cors: true,
				dataType: 'json',

			})
		.done(
			function(data) {
				$('#specializationdiv').unblock();
				if (data.status == '1') {
					swal(data.message)
						.then((value) => {
							window.location.reload();
						});
				} else {
					swal(data.message);
				}
			})
		.fail(function(jqXHR, textStatus) {
			$('#specializationdiv').unblock();
			swal(jqXHR.responseText);
			//swal('File upload failed ...');
		});
}
function isValidFileName(str) {
	return /^([a-zA-Z0-9.]+)$/g.test(str);
}

function GetSpecializationData(sid) {
	$('#specializationdiv').block({ message: 'Please wait....' });
	var jsondata = {
		"sid": sid
	}
	$
		.ajax(
			{
				url: '/AFMS/admin/GetSpecializationDataForUpdate',
				type: "POST",
				data: JSON
					.stringify(jsondata),
				contentType: 'application/json',
				cors: true,
				dataType: 'json',

			})
		.done(
			function(data) {
				$('#specializationdiv').unblock();
				if (data.status == '1') {
					document.getElementById("coursename").value = data.coursename;

					document.getElementById("sid").value = data.sid;
					document.getElementById("actiontype").value = "Edit";
					document.getElementById("specializebtn").value = "Update";
				} else {
					swal(data.message);
				}
			})
		.fail(function(jqXHR, textStatus) {
			$('#specializationdiv').unblock();
			swal(jqXHR.responseText);
		});
}
function DeleteDocumentData(sid) {
	$('#specializationdiv').block({ message: 'Please wait....' });
	var jsondata = {
		"sid": sid
	}
	$
		.ajax(
			{
				url: '/AFMS/admin/DeleteSpecialiaztionData',
				type: "POST",
				data: JSON
					.stringify(jsondata),
				contentType: 'application/json',
				cors: true,
				dataType: 'json',

			})
		.done(
			function(data) {
				$('#specializationdiv').unblock();
				if (data.status == '1') {
					swal(data.message)
						.then((value) => {
							window.location.reload();
						});
				} else {
					swal(data.message);
				}
			})
		.fail(function(jqXHR, textStatus) {
			$('#specializationdiv').unblock();
			swal(jqXHR.responseText);

		});
}