$(document).ready(function() {
	var table = $('#rolemastertbl').DataTable({
		rowReorder: {
			selector: 'td:nth-child(2)'
		},
		responsive: true,
		"scrollY": "400px",
		"scrollX": true,
		"scrollCollapse": true,
	});

	getRoleType();
});
$(document).ready(function() {

	$("#rolename").keypress(function(event) {
		var inputValue = event.which;

		// allow letters and whitespaces only.
		if (!(inputValue == 32) && // space
			!(inputValue > 48 && inputValue < 58) && // numeric (0-9)
			!(inputValue > 64 && inputValue < 91) && // upper alpha (A-Z)
			!(inputValue > 96 && inputValue < 123)) {
			event.preventDefault();
		}
	});
	$('#rolemasterdiv').block({ message: 'Please wait....' });
	$.ajax(
		{
			url: '/AFMS/admin/LoadRoleMasterData',
			type: "POST",
			contentType: 'application/json',
			dataType: 'json',

		})
		.done(
			function(data) {

				if (data.status == '1') {


					var length = Object.keys(data.data).length;

					$('#rolemastertbl').dataTable().fnClearTable();
					for (var i = 0; i < length; i++) {
						var statusData = data.data[i];
						$('#rolemastertbl').dataTable().fnAddData([
							statusData.srno,
							statusData.rolename,
							statusData.roleurl,
							statusData.roletype,
							statusData.accesslevel,
							statusData.subaccesslevel,
							statusData.stafflevel,
							statusData.action


						]);
					}
					$('#rolemasterdiv').unblock();
				} else {
					$('#rolemasterdiv').unblock();
					swal(data.message);
				}

			})
		.fail(function(jqXHR, textStatus) {
			$('#rolemasterdiv').unblock();
			swal(jqXHR.responseText);
		});

});
function SaveRoleMasterData() {
	var rolename = document.getElementById("rolename").value.trim();
	var roleurl = document.getElementById("roleurl").value.trim();
	var roletype = $('#roletype').val().trim();

	var accesslevel = $('#accesslevel').val().trim();
	if (rolename == "" || rolename == null || rolename == undefined) {
		swal('Please Enter Role Name');
		return false;
	}
	if (rolename.length < 2) {
		swal('Role Name must be of atleast 2 letters.');
		return false;
	}
	if (roleurl == "" || roleurl == null || roleurl == undefined) {
		swal('Please Enter Role URL');
		return false;
	}
	if (roleurl.length < 4) {
		swal('Role URL must be of atleast 4 letters.');
		return false;
	}

	if (roletype == "" || roletype == null || roletype == undefined || roletype == "-1") {
		swal('Please Select Role Type');
		return false;
	}
	if (accesslevel == "" || accesslevel == null || accesslevel == undefined || accesslevel == "-1") {
		swal('Please Select Access Level');
		return false;
	}



	$('#rolemasterdiv').block({ message: 'Please wait....' });
	var jsondata = {
		"rolename": rolename,
		"roleurl": roleurl,
		"roletype": roletype,
		"accesslevel": accesslevel,
		"actiontype": document.getElementById("actiontype").value,
		"roleid": document.getElementById("roleid").value
	}

	$
		.ajax(
			{
				url: '/AFMS/admin/SaveRoleMasterData',
				type: "POST",
				data: JSON
					.stringify(jsondata),
				contentType: 'application/json',
				cors: true,
				dataType: 'json',

			})
		.done(
			function(data) {
				$('#rolemasterdiv').unblock();
				if (data.status == '1') {


					swal(data.message)
						.then((value) => {
							window.location.reload();
						});


				} else {
					swal(data.message);




				}
			})
		.fail(function(jqXHR, textStatus) {
			swal(jqXHR.responseText);
			//swal('File upload failed ...');
		});

}

function GetRoleData(roleid) {

	$('#rolemasterdiv').block({ message: 'Please wait....' });
	var jsondata = {
		"roleid": roleid
	}

	$
		.ajax(
			{
				url: '/AFMS/admin/GetRoleDataForUpdate',
				type: "POST",
				data: JSON
					.stringify(jsondata),
				contentType: 'application/json',
				cors: true,
				dataType: 'json',

			})
		.done(
			function(data) {
				$('#rolemasterdiv').unblock();
				if (data.status == '1') {
					document.getElementById("rolename").value = data.rolename;
					document.getElementById("roleid").value = data.roleid;
					document.getElementById("roleurl").value = data.roleurl;
					var accesslevel = data.accesslevel;
					var roletype = data.roletype;
					alert(roletype);
					$('#rolemasterdiv').block({ message: 'Please wait....' });

					$
						.ajax(
							{
								url: '/AFMS/admin/GetRoleType',
								type: "POST",

								cors: true,
								dataType: 'json',

							})
						.done(
							function(data) {
								$('#rolemasterdiv').unblock();
								var selectHtml = "";
								selectHtml = selectHtml + "<option value='-1'>--Select Role Type---</option>";
								$.each(data.roletypelist, function(jdIndex, jdData) {
									selectHtml = selectHtml + "<option value='" + jdData.name + "'>" + jdData.name + "</option>";
								});
								$('#roletype').html(selectHtml);
								$('#roletype').val(roletype);
							})
						.fail(function(jqXHR, textStatus) {
							$('#rolemasterdiv').unblock();
							swal(jqXHR.responseText);

						});

					$('#accesslevel').val(accesslevel);
					document.getElementById("actiontype").value = "Edit";
					document.getElementById("docbtn").value = "Update";
				} else {
					swal(data.message);
				}
			})
		.fail(function(jqXHR, textStatus) {
			//swal(jqXHR.responseText);
			swal('File upload failed ...');
		});
}
function DeleteRoleData(roleid) {
	$('#rolemasterdiv').block({ message: 'Please wait....' });
	var jsondata = {
		"roleid": roleid
	}

	$
		.ajax(
			{
				url: '/AFMS/admin/DeleteRoleData',
				type: "POST",
				data: JSON
					.stringify(jsondata),
				contentType: 'application/json',
				cors: true,
				dataType: 'json',

			})
		.done(
			function(data) {
				$('#rolemasterdiv').unblock();
				if (data.status == '1') {
					swal(data.message)
						.then((value) => {
							window.location.reload();
						});
				} else {
					swal(data.message);
				}
			})
		.fail(function(jqXHR, textStatus) {
			$('#rolemasterdiv').unblock();
			swal(jqXHR.responseText);

		});

}

function ResetInput() {
	window.location.reload();
}
function getRoleType() {


	$('#rolemasterdiv').block({ message: 'Please wait....' });

	$
		.ajax(
			{
				url: '/AFMS/admin/GetRoleType',
				type: "POST",

				cors: true,
				dataType: 'json',

			})
		.done(
			function(data) {
				$('#rolemasterdiv').unblock();
				var selectHtml = "";
				selectHtml = selectHtml + "<option value='-1'>--Select Role Type---</option>";
				$.each(data.roletypelist, function(jdIndex, jdData) {
					selectHtml = selectHtml + "<option value='" + jdData.name + "'>" + jdData.name + "</option>";
				});
				$('#roletype').html(selectHtml);
			})
		.fail(function(jqXHR, textStatus) {
			$('#rolemasterdiv').unblock();
			swal(jqXHR.responseText);

		});

}