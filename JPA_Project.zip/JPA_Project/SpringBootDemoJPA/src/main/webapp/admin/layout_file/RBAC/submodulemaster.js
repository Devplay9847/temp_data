$(document).ready(function() {
	var table = $('#submodulemastertbl').DataTable({
		rowReorder: {
			selector: 'td:nth-child(2)'
		},
		responsive: true,
		"scrollY": "400px",
		"scrollX": true,
		"scrollCollapse": true,
	});

	getModuleName();
});
$(document).ready(function() {

	$("#submodname").keypress(function(event) {
		var inputValue = event.which;

		// allow letters and whitespaces only.
		if (!(inputValue == 32) && // space
			!(inputValue > 48 && inputValue < 58) && // numeric (0-9)
			!(inputValue > 64 && inputValue < 91) && // upper alpha (A-Z)
			!(inputValue > 96 && inputValue < 123)) {
			event.preventDefault();
		}
	});
	$('#submodulemasterdiv').block({ message: 'Please wait....' });
	$.ajax(
		{
			url: '/AFMS/admin/LoadSubModuleMasterData',
			type: "POST",
			contentType: 'application/json',
			dataType: 'json',

		})
		.done(
			function(data) {

				if (data.status == '1') {


					var length = Object.keys(data.data).length;

					$('#submodulemastertbl').dataTable().fnClearTable();
					for (var i = 0; i < length; i++) {
						var statusData = data.data[i];
						$('#submodulemastertbl').dataTable().fnAddData([
							statusData.srno,
							statusData.modulename,
							statusData.submodulename,
							statusData.action


						]);
					}
					$('#submodulemasterdiv').unblock();
				} else {
					$('#submodulemasterdiv').unblock();
					swal(data.message);
				}

			})
		.fail(function(jqXHR, textStatus) {
			$('#submodulemasterdiv').unblock();
			swal(jqXHR.responseText);
		});

});
function SaveSubModuleMasterData() {
	var submodname = document.getElementById("submodname").value.trim();

	var modulename = $('#modulename').val().trim();


	if (submodname == "" || submodname == null || submodname == undefined) {
		swal('Please Enter Sub Module Name');
		return false;
	}
	if (submodname.length < 2) {
		swal('Sub Module Name must be of atleast 2 letters.');
		return false;
	}


	if (modulename == "" || modulename == null || modulename == undefined || modulename == "-1") {
		swal('Please Select Module');
		return false;
	}



	$('#submodulemasterdiv').block({ message: 'Please wait....' });
	var jsondata = {
		"submodname": submodname,
		"modulename": modulename,

		"actiontype": document.getElementById("actiontype").value,
		"submoduleid": document.getElementById("submoduleid").value
	}

	$
		.ajax(
			{
				url: '/AFMS/admin/SaveSubModuleMasterData',
				type: "POST",
				data: JSON
					.stringify(jsondata),
				contentType: 'application/json',
				cors: true,
				dataType: 'json',

			})
		.done(
			function(data) {
				$('#submodulemasterdiv').unblock();
				if (data.status == '1') {


					swal(data.message)
						.then((value) => {
							window.location.reload();
						});


				} else {
					swal(data.message);




				}
			})
		.fail(function(jqXHR, textStatus) {
			swal(jqXHR.responseText);
			//swal('File upload failed ...');
		});

}

function GetSubModuleData(submoduleid) {

	$('#submodulemasterdiv').block({ message: 'Please wait....' });
	var jsondata = {
		"submoduleid": submoduleid
	}

	$
		.ajax(
			{
				url: '/AFMS/admin/GetSubModuleDataForUpdate',
				type: "POST",
				data: JSON
					.stringify(jsondata),
				contentType: 'application/json',
				cors: true,
				dataType: 'json',

			})
		.done(
			function(data) {
				$('#submodulemasterdiv').unblock();
				if (data.status == '1') {
					document.getElementById("submodname").value = data.submodname;
					document.getElementById("submoduleid").value = data.submoduleid;

					var modulename = data.modulename;

					$('#submodulemasterdiv').block({ message: 'Please wait....' });

					$
						.ajax(
							{
								url: '/AFMS/admin/getModuleName',
								type: "POST",

								cors: true,
								dataType: 'json',

							})
						.done(
							function(data) {
								$('#submodulemasterdiv').unblock();
								var selectHtml = "";
								selectHtml = selectHtml + "<option value='-1'>--Select Module Name---</option>";
								$.each(data.modulelist, function(jdIndex, jdData) {
									selectHtml = selectHtml + "<option value='" + jdData.id + "'>" + jdData.name + "</option>";
								});
								$('#modulename').html(selectHtml);
								$('#modulename').val(modulename);
							})
						.fail(function(jqXHR, textStatus) {
							$('#submodulemasterdiv').unblock();
							swal(jqXHR.responseText);

						});
					document.getElementById("actiontype").value = "Edit";
					document.getElementById("docbtn").value = "Update";
				} else {
					swal(data.message);
				}
			})
		.fail(function(jqXHR, textStatus) {
			//swal(jqXHR.responseText);
			swal('File upload failed ...');
		});
}
function DeleteSubModuleData(submoduleid) {
	$('#submodulemasterdiv').block({ message: 'Please wait....' });
	var jsondata = {
		"submoduleid": submoduleid
	}

	$
		.ajax(
			{
				url: '/AFMS/admin/DeleteSubModuleData',
				type: "POST",
				data: JSON
					.stringify(jsondata),
				contentType: 'application/json',
				cors: true,
				dataType: 'json',

			})
		.done(
			function(data) {
				$('#submodulemasterdiv').unblock();
				if (data.status == '1') {
					swal(data.message)
						.then((value) => {
							window.location.reload();
						});
				} else {
					swal(data.message);
				}
			})
		.fail(function(jqXHR, textStatus) {
			$('#submodulemasterdiv').unblock();
			swal(jqXHR.responseText);

		});

}

function ResetInput() {
	window.location.reload();
}
function getModuleName() {


	$('#submodulemasterdiv').block({ message: 'Please wait....' });

	$
		.ajax(
			{
				url: '/AFMS/admin/getModuleName',
				type: "POST",

				cors: true,
				dataType: 'json',

			})
		.done(
			function(data) {
				$('#submodulemasterdiv').unblock();
				var selectHtml = "";
				selectHtml = selectHtml + "<option value='-1'>--Select Module Name---</option>";
				$.each(data.modulelist, function(jdIndex, jdData) {
					selectHtml = selectHtml + "<option value='" + jdData.id + "'>" + jdData.name + "</option>";
				});
				$('#modulename').html(selectHtml);
			})
		.fail(function(jqXHR, textStatus) {
			$('#submodulemasterdiv').unblock();
			swal(jqXHR.responseText);

		});

}