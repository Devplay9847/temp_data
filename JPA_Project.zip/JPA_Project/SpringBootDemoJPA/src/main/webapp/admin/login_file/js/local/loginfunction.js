
$(document).ready(function() {
	$('#verifyandregister').prop('disabled', true);
	$("#fnameforreg").keypress(function(event) {
		var inputValue = event.which;
		// allow letters and whitespaces only.
		if (!(inputValue >= 65 && inputValue <= 120) && (inputValue != 32 && inputValue != 0 && inputValue != 8)) {
			event.preventDefault();
		}
	});
	$("#mnameforreg").keypress(function(event) {
		var inputValue = event.which;
		// allow letters and whitespaces only.
		if (!(inputValue >= 65 && inputValue <= 120) && (inputValue != 32 && inputValue != 0 && inputValue != 8)) {
			event.preventDefault();
		}
	});
	$("#lnameforreg").keypress(function(event) {
		var inputValue = event.which;
		// allow letters and whitespaces only.
		if (!(inputValue >= 65 && inputValue <= 120) && (inputValue != 32 && inputValue != 0 && inputValue != 8)) {
			event.preventDefault();
		}
	});
	$("#neetregno").keypress(function(event) {
		var inputValue = event.which;
		// allow letters and whitespaces only.
		if (!(inputValue >= 65 && inputValue <= 120) && !(inputValue >= 48 && inputValue <= 57) && (inputValue != 32 && inputValue != 8)) {
			event.preventDefault();
		}
	});
	$("#dnbpdcetno").keypress(function(event) {
		var inputValue = event.which;
		// allow letters and whitespaces only.
		if (!(inputValue >= 65 && inputValue <= 120) && !(inputValue >= 48 && inputValue <= 57) && (inputValue != 32 && inputValue != 8)) {
			event.preventDefault();
		}
	});
	/*$("#aadhaarnumber").keydown(function(event) {
		var inputValue = event.which;
		// allow letters and whitespaces only.
		if (!(inputValue >= 48 && inputValue <= 57) && (inputValue != 32 && inputValue != 0 && inputValue != 8)) {
			event.preventDefault();
		}
	});*/

	$("#otpforforgot").keypress(function(event) {
		var inputValue = event.which;
		// allow letters and whitespaces only.
		if (!(inputValue >= 48 && inputValue <= 57) && (inputValue != 32 && inputValue != 0 && inputValue != 8)) {
			event.preventDefault();
		}
	});
	$("#otp").keypress(function(event) {
		var inputValue = event.which;
		// allow letters and whitespaces only.
		if (!(inputValue >= 48 && inputValue <= 57) && (inputValue != 32 && inputValue != 0 && inputValue != 8)) {
			event.preventDefault();
		}
	});
	$('#dnbdiv').hide();
	$('input[type=radio][name=apptype]').change(function() {

		if (this.value == "NEET-PG") {
			$('#nameforreg').attr('placeholder',
				'Enter your Name as per NEET');
			$('#neetdiv').show();
			$('#dnbdiv').hide();
		} else if (this.value == "DNB-PDCET") {
			$('#nameforreg').attr('placeholder',
				'Enter your Name as per DNB-PDCET');

			$('#dnbdiv').show();
			$('#neetdiv').hide();
		}
	});
});
function sendOTPOnEmail() {

	$('#regModal').block({ message: 'Please wait....' });

	var apptype = $("input[name='apptype']:checked").val();
	var neetregnumber = "";
	var dnbpdcetnumber = "";
	var neetregnumberorpgdcer = "";
	if (apptype == "NEET-PG") {
		neetregnumberorpgdcer = document.getElementById("neetregno").value.trim();
		neetregnumber = document.getElementById("neetregno").value.trim();
	} else {
		neetregnumberorpgdcer = document.getElementById("dnbpdcetno").value.trim();
		dnbpdcetnumber = document.getElementById("dnbpdcetno").value.trim();
	}
	var fnameforreg = document.getElementById("fnameforreg").value.trim();
	var mnameforreg = document.getElementById("mnameforreg").value.trim();
	var lnameforreg = document.getElementById("lnameforreg").value.trim();
	var emailforreg = document.getElementById("emailforreg").value.trim();

	//var aadhaarnumber = document.getElementById("aadhaarnumber").value;
	var servicetype = $('#servicetype').val();
	if (fnameforreg == "" || fnameforreg == null || fnameforreg == undefined) {
		swal('Please Enter First Name');
		$('#regModal').unblock();
		return false;
	}
	if (fnameforreg.length < 3) {
		swal('First Name must be of atleast 3 letters.');
		$('#regModal').unblock();
		return false;
	}
	if (mnameforreg == "" || mnameforreg == null || mnameforreg == undefined) {
		swal('Please Enter Middle Name');
		$('#regModal').unblock();
		return false;
	}
	if (mnameforreg.length < 3) {
		swal('Middle Name must be of atleast 3 letters.');
		$('#regModal').unblock();
		return false;
	}
	if (lnameforreg == "" || lnameforreg == null || lnameforreg == undefined) {
		swal('Please Enter Last Name');
		$('#regModal').unblock();
		return false;
	}
	if (lnameforreg.length < 3) {
		swal('Last Name must be of atleast 3 letters.');
		$('#regModal').unblock();
		return false;
	}
	if (emailforreg == "" || emailforreg == null || emailforreg == undefined) {
		swal('Please Enter Email');
		$('#regModal').unblock();
		return false;
	}
	if (document.getElementById("emailforreg").value.length < 6) {
		swal('Email must be of atleast 6 letters.');
		$('#regModal').unblock();
		return false;
	}
	if (apptype == "NEET-PG") {
		if (neetregnumber == "" || neetregnumber == null || neetregnumber == undefined) {
			swal('Please Enter NEET Registration Number');
			$('#regModal').unblock();
			return false;
		}
		if (neetregnumber.length < 6) {
			swal('NEET Registration Number must be of atleast 6 letters.');
			$('#regModal').unblock();
			return false;
		}
	} else {
		if (dnbpdcetnumber == "" || dnbpdcetnumber == null || dnbpdcetnumber == undefined) {
			swal('Please Enter DNB-PDCET Number');
			$('#regModal').unblock();
			return false;
		}
		if (dnbpdcetnumber.length < 6) {
			swal('DNB-PDCET Registration Number must be of atleast 6 letters.');
			$('#regModal').unblock();
			return false;
		}
	}
	/*if (aadhaarnumber == "" || aadhaarnumber == null || aadhaarnumber == undefined) {
		swal('Please Enter Aadhaar Number');
		$('#regModal').unblock();
		return false;
	}*/
	/*if (aadhaarnumber.length !== 12) {
		swal('Aadhaar Number must be of 12 digits.');
		$('#regModal').unblock();
		return false;
	}*/
	var emailcheck = ValidateEmail(document.getElementById("emailforreg").value.trim());
	if (emailcheck) {
		var jsondata = {
			"fnameforreg": fnameforreg,
			"mnameforreg": mnameforreg,
			"lnameforreg": lnameforreg,
			"emailforreg": emailforreg,
			"neetregnumber": neetregnumberorpgdcer,
			//"aadhaarnumber": aadhaarnumber,
			"servicetype": servicetype,
			"apptype": apptype,

		}
		$('#otpNo').prop('disabled', true);
		$
			.ajax(
				{
					url: '/AFMS/CheckEmailExistandSendEmail',
					type: "POST",
					data: JSON
						.stringify(jsondata),
					contentType: 'application/json',
					cors: true,
					dataType: 'json',

				})
			.done(
				function(data) {
					$('#otpNo').prop('disabled', false);
					$('#regModal').unblock();
					if (data.status == '1') {

						swal(data.message);
						timer(60);
						$('#verifyandregister').prop('disabled', false);
					} else {
						swal(data.message);




					}
				})
			.fail(function(jqXHR, textStatus) {

				$('#regModal').unblock();
				swal(jqXHR.responseText);

			});
	} else {
		$('#regModal').unblock();
		swal("Please Enter Valid Email Address");
		return false
	}
}

function ValidateEmail(mail) {
	if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(mail)) {
		return (true)
	}
	swal("You have entered an invalid email address!")
	return (false)
}
function ValidateOTP(otp) {
	if (otp.length == 6) {
		return true;
	} else {
		return false;
	}
}


function VerifyOTPandRegister() {

	var apptype = $("input[name='apptype']:checked").val();
	var neetregnumber = "";
	var dnbpdcetnumber = "";
	var neetregnumberorpgdcer = "";
	if (apptype == "NEET-PG") {
		neetregnumberorpgdcer = document.getElementById("neetregno").value.trim();
		neetregnumber = document.getElementById("neetregno").value.trim();
	} else {
		neetregnumberorpgdcer = document.getElementById("dnbpdcetno").value.trim();
		dnbpdcetnumber = document.getElementById("dnbpdcetno").value.trim();
	}
	var fnameforreg = document.getElementById("fnameforreg").value.trim();
	var mnameforreg = document.getElementById("mnameforreg").value.trim();
	var lnameforreg = document.getElementById("lnameforreg").value.trim();
	var emailforreg = document.getElementById("emailforreg").value.trim();
	//var neetregnumber = document.getElementById("neetregno").value;
	//	var aadhaarnumber = document.getElementById("aadhaarnumber").value;
	var servicetype = $('#servicetype').val();
if (fnameforreg == "" || fnameforreg == null || fnameforreg == undefined) {
		swal('Please Enter First Name');
		$('#regModal').unblock();
		return false;
	}
	if (fnameforreg.length < 3) {
		swal('First Name must be of atleast 3 letters.');
		$('#regModal').unblock();
		return false;
	}
	if (mnameforreg == "" || mnameforreg == null || mnameforreg == undefined) {
		swal('Please Enter Middle Name');
		$('#regModal').unblock();
		return false;
	}
	if (mnameforreg.length < 3) {
		swal('Middle Name must be of atleast 3 letters.');
		$('#regModal').unblock();
		return false;
	}
	if (lnameforreg == "" || lnameforreg == null || lnameforreg == undefined) {
		swal('Please Enter Last Name');
		$('#regModal').unblock();
		return false;
	}
	if (lnameforreg.length < 3) {
		swal('Last Name must be of atleast 3 letters.');
		$('#regModal').unblock();
		return false;
	}
	if (emailforreg == "" || emailforreg == null || emailforreg == undefined) {
		swal('Please Enter Email');
		$('#regModal').unblock();
		return false;
	}
	if (document.getElementById("emailforreg").value.length < 6) {
		swal('Email must be of atleast 6 letters.');
		$('#regModal').unblock();
		return false;
	}
	if (apptype == "NEET-PG") {
		if (neetregnumber == "" || neetregnumber == null || neetregnumber == undefined) {
			swal('Please Enter NEET Registration Number');
			$('#regModal').unblock();
			return false;
		}
		if (neetregnumber.length < 6) {
			swal('NEET Registration Number must be of atleast 6 letters.');
			$('#regModal').unblock();
			return false;
		}
	} else {
		if (dnbpdcetnumber == "" || dnbpdcetnumber == null || dnbpdcetnumber == undefined) {
			swal('Please Enter DNB-PDCET Number');
			$('#regModal').unblock();
			return false;
		}
		if (dnbpdcetnumber.length < 6) {
			swal('DNB-PDCET Registration Number must be of atleast 6 letters.');
			$('#regModal').unblock();
			return false;
		}
	}
	/*if (aadhaarnumber == "" || aadhaarnumber == null || aadhaarnumber == undefined) {
		swal('Please Enter Aadhaar Number');
		$('#regModal').unblock();
		return false;
	}
	if (aadhaarnumber.length !== 12) {
		swal('Aadhaar Number must be of 12 digits.');
		$('#regModal').unblock();
		return false;
	}*/

	var otpcheck = ValidateOTP(document.getElementById("otp").value.trim());
	var emailcheck = ValidateEmail(document.getElementById("emailforreg").value.trim());

	if (otpcheck && emailcheck) {
		$('#regModal').block({ message: 'Please wait....' });
		var jsondataforreg = {
			"fnameforreg": fnameforreg,
			"mnameforreg": mnameforreg,
			"lnameforreg": lnameforreg,
			"emailforreg": emailforreg,
			"neetregnumber": neetregnumberorpgdcer,
			//"aadhaarnumber": aadhaarnumber,
			"servicetype": servicetype,
			"otpvalue": document.getElementById("otp").value,
			"apptype": apptype
		}
		$
			.ajax(
				{
					url: '/AFMS/VerifyEmailandRegister',
					type: "POST",
					data: JSON
						.stringify(jsondataforreg),
					contentType: 'application/json',
					cors: true,
					dataType: 'json',

				})
			.done(
				function(data) {
					$('#regModal').unblock();
					if (data.status == '1') {

						swal(data.message)
							.then((value) => {
								window.location.reload();
							});

					} else {
						swal(data.message);
					}

				})
			.fail(function(jqXHR, textStatus) {
				$('#regModal').unblock();
				swal('File upload failed ...');
			});
	} else {

		if (!otpcheck) {
			swal("OTP must be of 6 digits");
		} else {
			swal("You have entered an invalid email address!")
		}
	}
}


function sendOTPForForgotPassword() {

	$('#forgotModal').block({ message: 'Please wait....' });

	var username = document.getElementById("usernameforforgot").value.trim();

	var emailforforgot = document.getElementById("emailforforgot").value.trim();


	if (username == "" || username == null || username == undefined) {
		swal('Please Enter User Name');
		$('#forgotModal').unblock();
		return false;
	}
	if (username.length < 3) {
		swal('User Name must be of atleast 3 letters.');
		$('#forgotModal').unblock();
		return false;
	}
	if (emailforforgot == "" || emailforforgot == null || emailforforgot == undefined) {
		swal('Please Enter Email');
		$('#forgotModal').unblock();
		return false;
	}
	if (emailforforgot.length < 6) {
		swal('Email must be of atleast 6 letters.');
		$('#forgotModal').unblock();
		return false;
	}

	var emailcheck = ValidateEmail(emailforforgot);
	if (emailcheck) {
		var jsondata = {
			"username": username,
			"emailforforgot": emailforforgot


		}
		$('#otpNoforforgot').prop('disabled', true);
		$
			.ajax(
				{
					url: '/AFMS/CheckEmailForForgot',
					type: "POST",
					data: JSON
						.stringify(jsondata),
					contentType: 'application/json',
					cors: true,
					dataType: 'json',

				})
			.done(
				function(data) {
					$('#otpNoforforgot').prop('disabled', false);
					$('#forgotModal').unblock();
					if (data.status == '1') {

						swal(data.message);
						timerForgot(60);
						$('#verify').prop('disabled', false);
					} else {
						swal(data.message);
					}
				})
			.fail(function(jqXHR, textStatus) {

				$('#forgotModal').unblock();
				swal(jqXHR.responseText);

			});
	} else {
		$('#forgotModal').unblock();
		swal("Please Enter Valid Email Address");
		return false
	}
}

function VerifyOTP() {

	var username = document.getElementById("usernameforforgot").value.trim();

	var emailforforgot = document.getElementById("emailforforgot").value.trim();
	if (username == "" || username == null || username == undefined) {
		swal('Please Enter User Name');
		$('#forgotModal').unblock();
		return false;
	}
	if (username.length < 3) {
		swal('User Name must be of atleast 3 letters.');
		$('#forgotModal').unblock();
		return false;
	}
	if (emailforforgot == "" || emailforforgot == null || emailforforgot == undefined) {
		swal('Please Enter Email');
		$('#forgotModal').unblock();
		return false;
	}
	if (emailforforgot.length < 6) {
		swal('Email must be of atleast 6 letters.');
		$('#forgotModal').unblock();
		return false;
	}

	var emailcheck = ValidateEmail(emailforforgot);
	var otpcheck = ValidateOTP(document.getElementById("otpforforgot").value.trim());


	if (otpcheck && emailcheck) {
		$('#forgotModal').block({ message: 'Please wait....' });
		var jsondataforreg = {
			"username": username,
			"emailforforgot": emailforforgot,
			"otpvalue": document.getElementById("otpforforgot").value,

		}
		$
			.ajax(
				{
					url: '/AFMS/VerifyEmailandChangePassword',
					type: "POST",
					data: JSON
						.stringify(jsondataforreg),
					contentType: 'application/json',
					cors: true,
					dataType: 'json',

				})
			.done(
				function(data) {
					$('#forgotModal').unblock();
					if (data.status == '1') {

						swal(data.message)
							.then((value) => {
								window.location.reload();
							});

					} else {
						swal(data.message);
					}

				})
			.fail(function(jqXHR, textStatus) {
				$('#forgotModal').unblock();
				swal(jqXHR.responseText);
			});
	} else {

		if (!otpcheck) {
			swal("OTP must be of 6 digits");
		} else {
			swal("You have entered an invalid email address!")
		}
	}
}

var timerOnforgot = true;
function timerForgot(remaining) {
	var m = Math.floor(remaining / 60);
	var s = remaining % 60;

	m = m < 10 ? '0' + m : m;
	s = s < 10 ? '0' + s : s;
	document.getElementById('timerforgot').innerHTML = '<span class="timer"><b>OTP Expires in '
		+ m + ':' + s + '</b></span>';
	remaining -= 1;

	if (remaining >= 0 && timerOn) {
		setTimeout(function() {
			timer(remaining);
		}, 1000);
		$("#otpNoforforgot").html('Resend OTP');
		$("#otpNoforforgot").attr('disabled', true);
		return;
	} else {
		$("#otpNoforforgot").attr('disabled', false);
		return;
	}
	if (!timerOnforgot) {
		return;
	}
	/* 	$("input#otpNo").val("Resend OTP");*/
	$("input#otpNoforforgot").attr('disabled', false);

}
function SubmitLogin() {
	var ck_username = /^[A-Za-z0-9_]{1,20}$/;
	var ck_password = /^[A-Za-z0-9!@#$%^&*()_]{6,20}$/;
	var a = document.getElementById("username");
	if (a.value == "" || a.value == "'" || a.value == null
		|| a.value.toString().trim() == "" || a.value == "'''") {
		swal("Enter username");
		a.focus();
		return false;
	}
	var b = document.getElementById("password");
	if (b.value == "" || b.value == "'" || b.value == null
		|| b.value.toString().trim() == "") {
		swal("Enter password");
		b.focus();
		return false;
	}
	var iCapcha = removeSpaces(jQuery('#txtInput').val());
	if (iCapcha == "" || iCapcha.length != 5) {
		swal("Enter valid Captcha!");
		jQuery('#txtInput').focus();
		return false;
	}
	if (iCapcha != "") {
		var test = ValidCaptcha(iCapcha);
		if (test != "0") {
			jQuery('#csrfIdSet').attr('name', csrfparname);
			jQuery('#csrfIdSet').attr('value', csrfvalue);
			jQuery('#myFormId').attr('action', yuji);
			
			return true;
		} else {
			alert("Captcha Validation failed!");
			jQuery('#txtInput').focus();
			return false;
		}
	}
	return false;
}