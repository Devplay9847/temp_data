
function getRefreshReport(page,msg)
{
	//alert(msg+"=====================getid");
	if(msg.includes("Updated+Successfully"))
	{
		///////// pers_trans_weap
		if(page == "wepecond_per")
		{
			closeWindow();
			Search();
		}
		
		///////// en pers_trans_weap
		
		///////// Personnel
		if(page == "std_per")
		{
			closeWindow();
			Search();
		}
		if(page == "mod_per")
		{
			closeWindow();
			Search();
		}
		if(page == "foot_per")
		{
			closeWindow();
			Search();
		}
		
		if(page == "apptrade_per")
		{
			closeWindow()
			Search();
		}
		if(page == "capgspool_per")
		{
			closeWindow();
			Search();
		}
		/////////// end personnel
		
		////////// transport
		if(page == "std_trans")
		{
			closeWindow();
			Search();
		}
		if(page == "mod_trans")
		{
			closeWindow();
			Search();
		}
		if(page == "foot_trans")
		{
			closeWindow();
			Search();
		}
		
		if(page == "inlieu_trans")
		{
			closeWindow();
			Search();
		}
		////////// end transport
		
		//////// weapon
		if(page == "auth_std_weap")
		{
			closeWindow();
			Search();
		}
		if(page == "weap_auth_weap")
		{
			closeWindow();
			Search();
		}
		if(page == "in_de_foot_weap")
		{
			closeWindow();
			Search();
		}
		
		if(page == "upl_wet_pet_sup_weap")
		{
			closeWindow();
			Search();
		}
		if(page == "wet_pet_amend_weap")
		{
			closeWindow();
			Search();
		}
		
		if(page == "link_we_wet_weap")
		{
			closeWindow();
			Search();
		}
		if(page == "link_wet_we_weap")
		{
			closeWindow();
			Search();
		}
		
		if(page == "we_pe_upload_weap")
		{
			closeWindow();
			Search();
		}
		if(page == "upload_amnd_wepe_weap")
		{
			closeWindow();
			Search();
		}
		
		if(page == "wet_pet_upload_weap")
		{
			closeWindow();
			Search();
		}
		if(page == "wet_pet_amndmt_weap")
		{
			closeWindow();
			Search();
		}
		
		if(page == "prf_weap")
		{
			closeWindow();
			Search();
		}
		if(page == "item_mst_weap")
		{
			closeWindow();
			Search();
		}
		
		if(page == "ces_wea")
		{
			closeWindow();
			Search();
		}
		/////// end weapon
		
		/////////// provision
		if(page == "prov_weap")
		{
			closeWindow();
			Search();
		}
		if(page == "prov_mst_trans")
		{
			closeWindow();
			Search();
		}
		
		/////////// end provision
		
		////////// link sus no.
		if(page == "link_pers")
		{
			closeWindow();
			Search();
		}
		if(page == "link_weap")
		{
			closeWindow();
			Search();
		}
		if(page == "link_trans")
		{
			closeWindow();
			Search();
		}
		////////// end link sus no.

	}
}